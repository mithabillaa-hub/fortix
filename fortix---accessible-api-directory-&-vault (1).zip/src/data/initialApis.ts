import { ApiItem } from '../types';
import { FORTIX_DATASET } from './fortixDataset';

export const INITIAL_APIS: ApiItem[] = FORTIX_DATASET;
