import { ApiItem } from '../types';
import { INITIAL_APIS } from '../data/initialApis';

const STORAGE_KEY = 'fortix_apis_dataset_v2';
const MASKED_PREF_KEY = 'fortix_mask_preference';

export function loadSavedApis(): ApiItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      saveApis(INITIAL_APIS);
      return INITIAL_APIS;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
  } catch (err) {
    console.error('Failed to load saved APIs from storage:', err);
  }
  return INITIAL_APIS;
}

export function saveApis(items: ApiItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch (err) {
    console.error('Failed to save APIs to storage:', err);
  }
}

export function loadMaskPreference(): boolean {
  try {
    const pref = localStorage.getItem(MASKED_PREF_KEY);
    return pref !== 'false'; // default true
  } catch {
    return true;
  }
}

export function saveMaskPreference(masked: boolean): void {
  try {
    localStorage.setItem(MASKED_PREF_KEY, String(masked));
  } catch {
    // ignore
  }
}
