import { ThemePalette, ThemePaletteId } from '../types';

export const THEME_PALETTES: Record<ThemePaletteId, ThemePalette> = {
  cersanit: {
    id: 'cersanit',
    name: 'Cersanit Architectural Studio',
    description: 'Clean architectural white, stone gray, refined dark graphite, and restrained cobalt blue.',
    colors: ['#FFFFFF', '#F8F9FA', '#E2E8F0', '#0F172A', '#1D4ED8', '#0284C7'],
    primaryAccent: '#1D4ED8',
    secondaryAccent: '#0284C7',
    bgDark: '#0B0F19',
    cardDark: '#111827',
    borderDark: '#1E293B',
    bgLight: '#F8F9FA',
    cardLight: '#FFFFFF',
    borderLight: '#E2E8F0',
  },
  segesta: {
    id: 'segesta',
    name: 'Segesta Twilight',
    description: 'User-provided sunset palette with Midnight, Twilight, Sunset Peach, Crimson & Wine.',
    colors: ['#16152F', '#242F49', '#384358', '#FFA586', '#B51A2B', '#541A2E'],
    primaryAccent: '#FFA586',
    secondaryAccent: '#B51A2B',
    bgDark: '#16152F',
    cardDark: '#242F49',
    borderDark: '#384358',
    bgLight: '#FAF9F6',
    cardLight: '#FFFFFF',
    borderLight: '#E5E7EB',
  },
  'fortix-gold': {
    id: 'fortix-gold',
    name: 'FORTIX Royal Gold',
    description: 'Warm gold and amber lighting with carbon graphite and subtle champagne reflections.',
    colors: ['#0B0C10', '#171821', '#282B36', '#E6AF2E', '#FFB800', '#F3E9D2'],
    primaryAccent: '#E6AF2E',
    secondaryAccent: '#FFB800',
    bgDark: '#0B0C10',
    cardDark: '#171821',
    borderDark: '#2C3040',
    bgLight: '#F8F9FA',
    cardLight: '#FFFFFF',
    borderLight: '#E2E8F0',
  },
  'cyber-cyan': {
    id: 'cyber-cyan',
    name: 'Cyber Cyan & Indigo',
    description: 'Futuristic cyber aesthetic with electric cyan glow and obsidian indigo.',
    colors: ['#080C14', '#111A2E', '#1D2A47', '#00F0FF', '#3B82F6', '#8B5CF6'],
    primaryAccent: '#00F0FF',
    secondaryAccent: '#8B5CF6',
    bgDark: '#080C14',
    cardDark: '#111A2E',
    borderDark: '#1F3154',
    bgLight: '#F5F8FF',
    cardLight: '#FFFFFF',
    borderLight: '#CBD5E1',
  },
  monochrome: {
    id: 'monochrome',
    name: 'Titanium Monochrome',
    description: 'Brushed titanium, platinum silver, and subtle champagne gold.',
    colors: ['#0A0A0C', '#18181B', '#27272A', '#E4E4E7', '#D4AF37', '#FAFAFA'],
    primaryAccent: '#D4AF37',
    secondaryAccent: '#E4E4E7',
    bgDark: '#0A0A0C',
    cardDark: '#18181B',
    borderDark: '#3F3F46',
    bgLight: '#F4F4F5',
    cardLight: '#FFFFFF',
    borderLight: '#E4E4E7',
  },
};

export const getSavedPalette = (): ThemePaletteId => {
  try {
    const saved = localStorage.getItem('fortix_palette') as ThemePaletteId;
    if (saved && THEME_PALETTES[saved]) {
      return saved;
    }
  } catch {
    // fallback
  }
  return 'cersanit';
};

export const savePalette = (palette: ThemePaletteId) => {
  try {
    localStorage.setItem('fortix_palette', palette);
  } catch {
    // ignore
  }
};
