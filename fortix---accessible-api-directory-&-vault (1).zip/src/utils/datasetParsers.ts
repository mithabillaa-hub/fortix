import { ApiItem, ApiStatus, AuthType } from '../types';

/**
 * Intelligent parser that accepts text (CSV, TSV, JSON, or delimited lines)
 * and turns it into clean ApiItem[] objects.
 */

// Helper to sanitize string
const clean = (val: unknown): string => {
  if (val === null || val === undefined) return '';
  return String(val).trim();
};

export function parseDatasetInput(rawText: string): { items: Partial<ApiItem>[]; detectedFormat: string } {
  const text = rawText.trim();
  if (!text) {
    return { items: [], detectedFormat: 'empty' };
  }

  // 1. Check if Markdown Table with Categories (like the Public APIs list)
  if (text.includes('|') && (text.includes('###') || text.includes('|:--') || text.includes('Description'))) {
    const mdItems = parseMarkdownPublicApis(text);
    if (mdItems.length > 0) {
      return { items: mdItems, detectedFormat: 'Markdown Table (Public APIs)' };
    }
  }

  // 2. Check if JSON
  if (text.startsWith('[') || text.startsWith('{')) {
    try {
      const parsed = JSON.parse(text);
      let rawArray: Record<string, unknown>[] = [];
      if (Array.isArray(parsed)) {
        rawArray = parsed;
      } else if (typeof parsed === 'object' && parsed !== null) {
        // Look for common array wrappers
        const candidateKey = Object.keys(parsed).find(k => Array.isArray((parsed as Record<string, unknown>)[k]));
        if (candidateKey) {
          rawArray = (parsed as Record<string, unknown>)[candidateKey] as Record<string, unknown>[];
        } else {
          // single object
          rawArray = [parsed as Record<string, unknown>];
        }
      }

      if (rawArray.length > 0) {
        const items = rawArray.map((row, idx) => mapObjectToApiItem(row, idx));
        return { items, detectedFormat: 'JSON' };
      }
    } catch {
      // not valid JSON, proceed to CSV/TSV
    }
  }

  // 2. CSV / TSV / Delimited lines
  const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  if (lines.length === 0) return { items: [], detectedFormat: 'unknown' };

  // Determine delimiter: tab, comma, semicolon, pipe
  const firstLine = lines[0];
  let delimiter = ',';
  if (firstLine.includes('\t')) delimiter = '\t';
  else if (firstLine.includes('|')) delimiter = '|';
  else if (firstLine.includes(';') && !firstLine.includes(',')) delimiter = ';';

  // Check if first row has header
  const rawRows = lines.map(line => parseDelimitedLine(line, delimiter));
  if (rawRows.length === 0) return { items: [], detectedFormat: 'unknown' };

  const firstRow = rawRows[0];
  const isHeader = isLikelyHeader(firstRow);

  let headers: string[] = [];
  let dataRows: string[][] = [];

  if (isHeader) {
    headers = firstRow.map(h => h.toLowerCase().replace(/[^a-z0-9_]/g, ''));
    dataRows = rawRows.slice(1);
  } else {
    // Default column order guessing
    headers = inferDefaultHeaders(firstRow.length);
    dataRows = rawRows;
  }

  const items = dataRows.map((row, idx) => {
    const rowObj: Record<string, string> = {};
    headers.forEach((header, colIdx) => {
      rowObj[header] = row[colIdx] || '';
    });
    return mapObjectToApiItem(rowObj, idx);
  });

  return { items, detectedFormat: delimiter === '\t' ? 'TSV / Spreadsheet' : delimiter === '|' ? 'Piped Table' : 'CSV' };
}

function parseDelimitedLine(line: string, delimiter: string): string[] {
  if (delimiter === '\t' || delimiter === '|') {
    return line.split(delimiter).map(s => s.trim());
  }

  // Proper CSV parsing handling quotes
  const results: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"' || char === "'") {
      if (inQuotes && line[i + 1] === char) {
        current += char;
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === delimiter && !inQuotes) {
      results.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  results.push(current.trim());
  return results;
}

function isLikelyHeader(row: string[]): boolean {
  const headerKeywords = ['name', 'url', 'key', 'apikey', 'endpoint', 'category', 'auth', 'doc', 'description', 'status', 'token'];
  const matchCount = row.filter(cell => {
    const normalized = cell.toLowerCase().replace(/[^a-z0-9]/g, '');
    return headerKeywords.some(kw => normalized.includes(kw));
  }).length;
  return matchCount >= 1;
}

function inferDefaultHeaders(colCount: number): string[] {
  // Common expected columns: Name, URL, API Key, Category, Docs, Description
  const defaults = ['name', 'url', 'apikey', 'category', 'authtype', 'docsurl', 'description'];
  return defaults.slice(0, colCount);
}

function mapObjectToApiItem(raw: Record<string, unknown>, idx: number): Partial<ApiItem> {
  const getField = (keys: string[]): string => {
    for (const k of keys) {
      for (const rawKey of Object.keys(raw)) {
        const normalized = rawKey.toLowerCase().replace(/[^a-z0-9]/g, '');
        if (normalized === k.toLowerCase().replace(/[^a-z0-9]/g, '')) {
          return clean(raw[rawKey]);
        }
      }
    }
    return '';
  };

  const name = getField(['name', 'title', 'api', 'service', 'apiname', 'servicename', 'label', 'provider']) || `API Entry ${idx + 1}`;
  const url = getField(['url', 'endpoint', 'baseurl', 'apiurl', 'host', 'link', 'address']);
  const apiKey = getField(['apikey', 'key', 'token', 'secret', 'apitoken', 'accesstoken', 'password', 'authkey', 'credentials']);
  const category = getField(['category', 'group', 'type', 'section', 'domain', 'genre', 'classification']) || 'General';
  const rawAuth = getField(['authtype', 'auth', 'authorization', 'security', 'method']).toLowerCase();
  const docsUrl = getField(['docsurl', 'docs', 'documentation', 'doc', 'docurl', 'spec', 'reference']);
  const description = getField(['description', 'desc', 'summary', 'about', 'details', 'info']);
  const rawTags = getField(['tags', 'tag', 'keywords', 'labels']);
  const statusStr = getField(['status', 'state']).toLowerCase();
  const rateLimit = getField(['ratelimit', 'limit', 'quota']);
  const notes = getField(['notes', 'comments', 'comment', 'remark', 'memo']);

  let authType: AuthType = 'header';
  if (rawAuth.includes('bearer') || apiKey.startsWith('sk-') || apiKey.startsWith('ghp_')) {
    authType = 'bearer';
  } else if (rawAuth.includes('query') || rawAuth.includes('param')) {
    authType = 'query';
  } else if (rawAuth.includes('basic')) {
    authType = 'basic';
  } else if (rawAuth.includes('oauth')) {
    authType = 'oauth2';
  } else if (!apiKey || rawAuth.includes('none') || rawAuth.includes('public')) {
    authType = 'none';
  }

  let status: ApiStatus = 'active';
  if (statusStr.includes('test')) status = 'testing';
  else if (statusStr.includes('deprecat')) status = 'deprecated';
  else if (statusStr.includes('expir')) status = 'expired';

  const tags = rawTags
    ? rawTags.split(/[,;|]/).map(t => t.trim()).filter(Boolean)
    : [category.toLowerCase().replace(/\s+/g, '-')];

  return {
    id: `api-custom-${Date.now()}-${idx}-${Math.random().toString(36).slice(2, 7)}`,
    name,
    url: url || 'https://',
    apiKey,
    category,
    authType,
    headerKey: authType === 'bearer' ? 'Authorization' : authType === 'header' ? 'x-api-key' : undefined,
    queryParamKey: authType === 'query' ? 'key' : undefined,
    docsUrl,
    description: description || `Access endpoint for ${name}`,
    tags,
    status,
    rateLimit,
    notes,
    isFavorite: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

export function exportDatasetToJson(items: ApiItem[], includeKeys = true): string {
  const exportData = items.map(item => ({
    name: item.name,
    category: item.category,
    url: item.url,
    apiKey: includeKeys ? item.apiKey : '••••••••',
    authType: item.authType,
    headerKey: item.headerKey,
    queryParamKey: item.queryParamKey,
    docsUrl: item.docsUrl,
    description: item.description,
    tags: item.tags,
    status: item.status,
    rateLimit: item.rateLimit,
    notes: item.notes,
  }));
  return JSON.stringify(exportData, null, 2);
}

export function exportDatasetToCsv(items: ApiItem[], includeKeys = true): string {
  const headers = ['Name', 'Category', 'URL', 'API Key', 'Auth Type', 'Header / Query Key', 'Docs URL', 'Status', 'Rate Limit', 'Description', 'Tags', 'Notes'];
  const rows = items.map(item => {
    const keyVal = includeKeys ? item.apiKey : '••••••••';
    const authKey = item.authType === 'query' ? item.queryParamKey : item.headerKey;
    const values = [
      item.name,
      item.category,
      item.url,
      keyVal,
      item.authType,
      authKey || '',
      item.docsUrl || '',
      item.status,
      item.rateLimit || '',
      item.description,
      item.tags.join(', '),
      item.notes || '',
    ];
    return values.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',');
  });
  return [headers.join(','), ...rows].join('\n');
}

export function exportDatasetToEnv(items: ApiItem[]): string {
  const lines = items
    .filter(item => Boolean(item.apiKey))
    .map(item => {
      const cleanKey = item.name.toUpperCase().replace(/[^A-Z0-9]/g, '_') + '_API_KEY';
      return `${cleanKey}="${item.apiKey}"`;
    });
  return `# Exported from Fortix Vault on ${new Date().toLocaleDateString()}\n` + lines.join('\n');
}

export function parseMarkdownPublicApis(text: string): Partial<ApiItem>[] {
  const lines = text.split(/\r?\n/);
  const items: Partial<ApiItem>[] = [];
  let currentCategory = 'General';

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i].trim();
    if (!rawLine) continue;

    // Detect category header (e.g., "### Animals", "## Animals", or "### Art & Design")
    if (rawLine.startsWith('#')) {
      const catMatch = rawLine.replace(/^#+\s*/, '').trim();
      if (catMatch && !catMatch.toLowerCase().includes('index') && !catMatch.toLowerCase().includes('learn more') && !catMatch.toLowerCase().includes('license')) {
        currentCategory = catMatch;
      }
      continue;
    }

    // Check if table row with pipe
    if (rawLine.startsWith('|') && rawLine.endsWith('|')) {
      // Skip header row or separator row
      if (rawLine.includes('---') || rawLine.toLowerCase().includes('description | auth')) {
        continue;
      }

      // Split columns
      const cols = rawLine.split('|').map(c => c.trim()).slice(1, -1);
      if (cols.length < 2) continue;

      const apiCol = cols[0];
      const descCol = cols[1] || '';
      const authCol = cols[2]?.replace(/`/g, '') || 'No';
      const httpsCol = cols[3] || 'Yes';
      const corsCol = cols[4] || 'Unknown';

      // Parse [Name](URL)
      const linkMatch = apiCol.match(/\[(.*?)\]\((.*?)\)/);
      const name = linkMatch ? linkMatch[1].trim() : apiCol.replace(/[[\]]/g, '').trim();
      const url = linkMatch ? linkMatch[2].trim() : '';

      if (!name || name.toLowerCase() === 'api') continue;

      let authType: AuthType = 'none';
      const lowerAuth = authCol.toLowerCase();
      if (lowerAuth.includes('apikey') || lowerAuth.includes('api key') || lowerAuth.includes('token')) {
        authType = 'header';
      } else if (lowerAuth.includes('oauth')) {
        authType = 'oauth2';
      } else if (lowerAuth.includes('mashape')) {
        authType = 'header';
      } else if (lowerAuth.includes('basic')) {
        authType = 'basic';
      } else if (lowerAuth.includes('no') || lowerAuth.includes('none') || !lowerAuth) {
        authType = 'none';
      }

      const tags: string[] = [
        currentCategory.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      ];
      if (authType !== 'none') tags.push(authCol.toLowerCase());
      if (corsCol.toLowerCase() === 'yes') tags.push('cors-enabled');
      if (httpsCol.toLowerCase() === 'yes') tags.push('https');

      items.push({
        id: `pub-${items.length + 1}-${name.toLowerCase().replace(/[^a-z0-9]/g, '-')}`,
        name,
        category: currentCategory,
        url: url || 'https://',
        apiKey: '',
        authType,
        headerKey: authType === 'header' ? 'X-API-Key' : undefined,
        docsUrl: url || undefined,
        description: descCol,
        tags,
        status: 'active',
        rateLimit: authType === 'none' ? 'Open / Public' : 'Free / Key required',
        notes: `Authentication: ${authCol} · HTTPS: ${httpsCol} · CORS: ${corsCol}`,
        isFavorite: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    }
  }

  return items;
}

