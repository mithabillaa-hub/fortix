import { ApiItem } from '../types';

export function generateCurlSnippet(api: ApiItem): string {
  let url = api.url || 'https://api.example.com';
  const headers: string[] = [];

  if (api.authType === 'bearer') {
    headers.push(`-H "Authorization: Bearer ${api.apiKey || 'YOUR_API_KEY'}"`);
  } else if (api.authType === 'header') {
    headers.push(`-H "${api.headerKey || 'X-API-Key'}: ${api.apiKey || 'YOUR_API_KEY'}"`);
  } else if (api.authType === 'basic') {
    headers.push(`-u "${api.apiKey || 'user:pass'}"`);
  } else if (api.authType === 'query') {
    const separator = url.includes('?') ? '&' : '?';
    url = `${url}${separator}${api.queryParamKey || 'key'}=${api.apiKey || 'YOUR_API_KEY'}`;
  }

  headers.push('-H "Accept: application/json"');

  return `curl -X GET "${url}" \\\n  ${headers.join(' \\\n  ')}`;
}

export function generateJsSnippet(api: ApiItem): string {
  let url = api.url || 'https://api.example.com';
  const headersObj: Record<string, string> = {
    Accept: 'application/json',
  };

  if (api.authType === 'bearer') {
    headersObj['Authorization'] = `Bearer ${api.apiKey || 'YOUR_API_KEY'}`;
  } else if (api.authType === 'header') {
    headersObj[api.headerKey || 'X-API-Key'] = api.apiKey || 'YOUR_API_KEY';
  } else if (api.authType === 'basic') {
    headersObj['Authorization'] = `Basic \${btoa('${api.apiKey || 'user:pass'}')}`;
  } else if (api.authType === 'query') {
    const separator = url.includes('?') ? '&' : '?';
    url = `${url}${separator}${api.queryParamKey || 'key'}=${api.apiKey || 'YOUR_API_KEY'}`;
  }

  return `const response = await fetch("${url}", {
  method: "GET",
  headers: ${JSON.stringify(headersObj, null, 4)}
});

const data = await response.json();
console.log(data);`;
}

export function generatePythonSnippet(api: ApiItem): string {
  let url = api.url || 'https://api.example.com';
  const headersLines: string[] = ['    "Accept": "application/json"'];
  let paramsLine = '';

  if (api.authType === 'bearer') {
    headersLines.push(`    "Authorization": f"Bearer ${api.apiKey || 'YOUR_API_KEY'}"`);
  } else if (api.authType === 'header') {
    headersLines.push(`    "${api.headerKey || 'X-API-Key'}": "${api.apiKey || 'YOUR_API_KEY'}"`);
  } else if (api.authType === 'query') {
    paramsLine = `params = {"${api.queryParamKey || 'key'}": "${api.apiKey || 'YOUR_API_KEY'}"}\n`;
  }

  const reqCall = paramsLine
    ? `response = requests.get("${url}", headers=headers, params=params)`
    : `response = requests.get("${url}", headers=headers)`;

  return `import requests

url = "${url}"
${paramsLine}headers = {
${headersLines.join(',\n')}
}

${reqCall}
print(response.status_code)
print(response.json())`;
}

export function generateGoSnippet(api: ApiItem): string {
  let url = api.url || 'https://api.example.com';
  let headerSet = '';

  if (api.authType === 'bearer') {
    headerSet = `\treq.Header.Set("Authorization", "Bearer ${api.apiKey || 'YOUR_API_KEY'}")\n`;
  } else if (api.authType === 'header') {
    headerSet = `\treq.Header.Set("${api.headerKey || 'X-API-Key'}", "${api.apiKey || 'YOUR_API_KEY'}")\n`;
  } else if (api.authType === 'query') {
    const separator = url.includes('?') ? '&' : '?';
    url = `${url}${separator}${api.queryParamKey || 'key'}=${api.apiKey || 'YOUR_API_KEY'}`;
  }

  return `package main

import (
\t"fmt"
\t"io"
\t"net/http"
)

func main() {
\tclient := &http.Client{}
\treq, err := http.NewRequest("GET", "${url}", nil)
\tif err != nil {
\t\tpanic(err)
\t}

${headerSet}\treq.Header.Set("Accept", "application/json")

\tresp, err := client.Do(req)
\tif err != nil {
\t\tpanic(err)
\t}
\tdefer resp.Body.Close()

\tbody, _ := io.ReadAll(resp.Body)
\tfmt.Println(string(body))
}`;
}
