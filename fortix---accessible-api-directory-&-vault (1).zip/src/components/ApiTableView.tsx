import React, { useState } from 'react';
import { ApiItem } from '../types';
import { Star, Copy, Check, ArrowUpRight, Eye, EyeOff, Edit2, Trash2 } from 'lucide-react';
import { generateCurlSnippet } from '../utils/codeGenerators';

interface ApiTableViewProps {
  items: ApiItem[];
  allKeysMasked: boolean;
  onEditApi: (api: ApiItem) => void;
  onDeleteApi: (id: string) => void;
  onToggleFavorite: (id: string) => void;
  onNotify: (msg: string) => void;
}

export const ApiTableView: React.FC<ApiTableViewProps> = ({
  items,
  allKeysMasked,
  onEditApi,
  onDeleteApi,
  onToggleFavorite,
  onNotify,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [revealedIds, setRevealedIds] = useState<Record<string, boolean>>({});

  const toggleReveal = (id: string) => {
    setRevealedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleCopy = (e: React.MouseEvent, text: string, label: string, id: string) => {
    e.stopPropagation();
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    onNotify(`Copied ${label}`);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleCopyCurl = (e: React.MouseEvent, api: ApiItem) => {
    e.stopPropagation();
    const curl = generateCurlSnippet(api);
    navigator.clipboard.writeText(curl);
    onNotify(`Copied cURL command for ${api.name}`);
  };

  if (items.length === 0) {
    return (
      <div className="py-20 text-center">
        <p className="text-sm font-medium text-neutral-600 dark:text-neutral-400">
          No APIs found matching current criteria.
        </p>
      </div>
    );
  }

  return (
    <div className="w-full overflow-x-auto p-4 sm:p-6 lg:p-8">
      <div className="border border-neutral-200 dark:border-neutral-800 rounded-xl overflow-hidden shadow-xs bg-white dark:bg-[#111827]">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-neutral-50 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-300 font-semibold border-b border-neutral-200 dark:border-neutral-800">
            <tr>
              <th scope="col" className="w-10 py-3.5 px-3 text-center">
                <span className="sr-only">Favorite</span>
              </th>
              <th scope="col" className="py-3.5 px-4 font-mono uppercase text-[10px] tracking-wider">API Name</th>
              <th scope="col" className="py-3.5 px-3 font-mono uppercase text-[10px] tracking-wider">Category</th>
              <th scope="col" className="py-3.5 px-3 font-mono uppercase text-[10px] tracking-wider">Endpoint URL</th>
              <th scope="col" className="py-3.5 px-3 font-mono uppercase text-[10px] tracking-wider">Auth Type</th>
              <th scope="col" className="py-3.5 px-3 font-mono uppercase text-[10px] tracking-wider">API Key / Secret</th>
              <th scope="col" className="py-3.5 px-4 text-right font-mono uppercase text-[10px] tracking-wider">Redirect & Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800 font-normal">
            {items.map((api) => {
              const isRevealed = Boolean(revealedIds[api.id]) || !allKeysMasked;
              const displayKey = api.apiKey
                ? isRevealed
                  ? api.apiKey
                  : `${api.apiKey.slice(0, 4)}••••${api.apiKey.slice(-4)}`
                : null;

              return (
                <tr
                  key={api.id}
                  className="hover:bg-neutral-50 dark:hover:bg-neutral-800/40 transition-colors"
                >
                  {/* Star */}
                  <td className="py-3.5 px-3 text-center" onClick={(e) => e.stopPropagation()}>
                    <button
                      onClick={() => onToggleFavorite(api.id)}
                      className="text-neutral-300 hover:text-amber-500 transition-colors"
                      aria-label={api.isFavorite ? 'Remove favorite' : 'Add favorite'}
                    >
                      <Star
                        className={`w-3.5 h-3.5 ${
                          api.isFavorite ? 'fill-current text-amber-500' : ''
                        }`}
                      />
                    </button>
                  </td>

                  {/* Name */}
                  <td className="py-3.5 px-4 font-semibold text-neutral-900 dark:text-neutral-100 max-w-[200px]">
                    <a
                      href={api.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="truncate font-semibold text-neutral-900 dark:text-neutral-100 hover:text-blue-600 dark:hover:text-blue-400 hover:underline block"
                    >
                      {api.name}
                    </a>
                    <div className="text-[11px] text-neutral-500 dark:text-neutral-400 truncate max-w-[220px] font-normal mt-0.5">
                      {api.description}
                    </div>
                  </td>

                  {/* Category */}
                  <td className="py-3.5 px-3 text-neutral-600 dark:text-neutral-300 whitespace-nowrap">
                    {api.category}
                  </td>

                  {/* Endpoint URL */}
                  <td className="py-3.5 px-3 font-mono text-[11px] text-neutral-600 dark:text-neutral-300 max-w-[220px]">
                    <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                      <a
                        href={api.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="truncate hover:underline text-neutral-600 dark:text-neutral-300 hover:text-blue-600 dark:hover:text-blue-400"
                      >
                        {api.url}
                      </a>
                      <button
                        onClick={(e) => handleCopy(e, api.url, 'URL', `${api.id}-url`)}
                        className="p-1 text-neutral-400 hover:text-neutral-800 dark:hover:text-neutral-200 shrink-0"
                        title="Copy URL"
                      >
                        {copiedId === `${api.id}-url` ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                      </button>
                    </div>
                  </td>

                  {/* Auth Type */}
                  <td className="py-3.5 px-3 text-neutral-600 dark:text-neutral-400 uppercase text-[10px] font-mono tracking-wide whitespace-nowrap">
                    {api.authType}
                  </td>

                  {/* API Key */}
                  <td className="py-3.5 px-3 font-mono text-[11px] text-neutral-600 dark:text-neutral-300 whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                    {displayKey ? (
                      <div className="flex items-center gap-1">
                        <span className="truncate max-w-[130px]">{displayKey}</span>
                        <button
                          onClick={() => toggleReveal(api.id)}
                          className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
                          title={isRevealed ? 'Mask key' : 'Reveal key'}
                        >
                          {isRevealed ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        </button>
                        <button
                          onClick={(e) => handleCopy(e, api.apiKey, 'API Key', `${api.id}-key`)}
                          className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
                          title="Copy Key"
                        >
                          {copiedId === `${api.id}-key` ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                        </button>
                      </div>
                    ) : (
                      <span className="text-neutral-400 dark:text-neutral-500 italic">None (Public)</span>
                    )}
                  </td>

                  {/* Redirect & Actions (Direct Visit Site ↗) */}
                  <td className="py-3.5 px-4 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center justify-end gap-1.5">
                      <a
                        href={api.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-neutral-900 text-white dark:bg-blue-600 dark:text-white hover:bg-neutral-800 dark:hover:bg-blue-500 inline-flex items-center gap-1 transition-all shadow-xs"
                        title={`Redirect to ${api.name}`}
                      >
                        <span>Visit Site</span>
                        <ArrowUpRight className="w-3 h-3" />
                      </a>
                      <button
                        onClick={(e) => handleCopyCurl(e, api)}
                        className="p-1.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded-md"
                        title="Copy cURL command"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onEditApi(api)}
                        className="p-1.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded-md"
                        title="Edit entry"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onDeleteApi(api.id)}
                        className="p-1.5 text-neutral-400 hover:text-rose-600 dark:hover:text-rose-400 rounded-md"
                        title="Delete entry"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
