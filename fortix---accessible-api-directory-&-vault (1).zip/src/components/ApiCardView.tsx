import React, { useState } from 'react';
import { ApiItem } from '../types';
import { Star, ArrowUpRight, Copy, Check, Eye, EyeOff, MoreVertical, Edit2, Trash2, Key, Globe, Shield } from 'lucide-react';

interface ApiCardViewProps {
  items: ApiItem[];
  allKeysMasked: boolean;
  onEditApi: (api: ApiItem) => void;
  onDeleteApi: (id: string) => void;
  onToggleFavorite: (id: string) => void;
  onNotify: (msg: string) => void;
}

export const ApiCardView: React.FC<ApiCardViewProps> = ({
  items,
  allKeysMasked,
  onEditApi,
  onDeleteApi,
  onToggleFavorite,
  onNotify,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [revealedIds, setRevealedIds] = useState<Record<string, boolean>>({});
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  const toggleReveal = (id: string) => {
    setRevealedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleCopyKeyOrUrl = (e: React.MouseEvent, text: string, label: string, id: string) => {
    e.stopPropagation();
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    onNotify(`Copied ${label}`);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (items.length === 0) {
    return (
      <div className="py-24 text-center">
        <p className="text-sm font-medium text-neutral-600 dark:text-neutral-400">
          No APIs match your search or filter criteria.
        </p>
        <p className="text-xs text-neutral-400 mt-1">
          Try resetting filters or searching with another keyword.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 p-4 sm:p-6 lg:p-8">
      {items.map((api) => {
        const isRevealed = Boolean(revealedIds[api.id]) || !allKeysMasked;
        const displayKey = api.apiKey
          ? isRevealed
            ? api.apiKey
            : `${api.apiKey.slice(0, 4)}••••••••${api.apiKey.slice(-4)}`
          : null;

        return (
          <div
            key={api.id}
            className="group relative flex flex-col justify-between rounded-xl p-5 transition-all duration-200 border bg-white dark:bg-[#111827] border-neutral-200/90 dark:border-neutral-800 hover:border-blue-500/70 dark:hover:border-blue-500/70 shadow-[0_2px_12px_rgba(0,0,0,0.03)] dark:shadow-[0_4px_20px_rgba(0,0,0,0.3)] hover:shadow-lg"
          >
            {/* Top Row: Clean unboxed metadata, Star, and Actions Menu */}
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                {/* Clean unboxed metadata with typographic dots */}
                <div className="flex items-center gap-1.5 text-xs text-neutral-500 dark:text-neutral-400 font-medium">
                  <span className="font-semibold text-neutral-800 dark:text-neutral-200">{api.category}</span>
                  <span aria-hidden="true" className="opacity-40">·</span>
                  <span className="uppercase text-[11px] font-mono tracking-wider text-neutral-500 dark:text-neutral-400">
                    {api.authType === 'none' ? 'Open API' : api.authType}
                  </span>
                  {api.url.startsWith('https://') && (
                    <>
                      <span aria-hidden="true" className="opacity-40">·</span>
                      <span className="text-[10px] text-blue-600 dark:text-blue-400 font-mono">HTTPS</span>
                    </>
                  )}
                </div>

                <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                  <button
                    onClick={() => onToggleFavorite(api.id)}
                    className="p-1 text-neutral-400 hover:text-amber-500 transition-colors"
                    title={api.isFavorite ? 'Remove from favorites' : 'Add to favorites'}
                    aria-label={api.isFavorite ? 'Remove from favorites' : 'Add to favorites'}
                  >
                    <Star
                      className={`w-4 h-4 ${api.isFavorite ? 'fill-current text-amber-500' : ''}`}
                    />
                  </button>

                  <div className="relative">
                    <button
                      onClick={() => setActiveMenuId(activeMenuId === api.id ? null : api.id)}
                      className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded-md"
                      aria-label="More actions"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>

                    {activeMenuId === api.id && (
                      <div className="absolute right-0 top-7 w-32 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl shadow-xl py-1 z-30 text-xs">
                        <button
                          onClick={() => {
                            setActiveMenuId(null);
                            onEditApi(api);
                          }}
                          className="w-full text-left px-3 py-1.5 flex items-center gap-2 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-200"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                          <span>Edit</span>
                        </button>
                        <button
                          onClick={() => {
                            setActiveMenuId(null);
                            onDeleteApi(api.id);
                          }}
                          className="w-full text-left px-3 py-1.5 flex items-center gap-2 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-400"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Title & Description */}
              <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                <a
                  href={api.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:underline flex items-center gap-1.5"
                >
                  <span>{api.name}</span>
                </a>
              </h3>
              <p className="text-xs text-neutral-600 dark:text-neutral-400 mt-1 line-clamp-2 leading-relaxed">
                {api.description || 'Public service endpoint for developer integrations.'}
              </p>

              {/* URL Box with Direct Redirect & Copy */}
              <div
                className="mt-3.5 flex items-center justify-between px-3 py-2 bg-neutral-50 dark:bg-neutral-950/60 border border-neutral-200/80 dark:border-neutral-800 rounded-lg text-xs transition-colors"
              >
                <a
                  href={api.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-mono text-[11px] text-neutral-600 dark:text-neutral-400 hover:text-blue-600 dark:hover:text-blue-400 truncate max-w-[85%] hover:underline flex items-center gap-1.5"
                  title="Click to visit website directly"
                >
                  <Globe className="w-3 h-3 text-neutral-400 shrink-0" />
                  <span className="truncate">{api.url}</span>
                </a>
                <button
                  onClick={(e) => handleCopyKeyOrUrl(e, api.url, 'URL', `${api.id}-url`)}
                  className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 shrink-0"
                  title="Copy URL"
                >
                  {copiedId === `${api.id}-url` ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                </button>
              </div>

              {/* Key Vault Field */}
              {displayKey && (
                <div
                  className="mt-2 flex items-center justify-between px-3 py-1.5 bg-neutral-50 dark:bg-neutral-950/40 border border-neutral-200/60 dark:border-neutral-800/80 rounded-lg text-xs"
                >
                  <div className="flex items-center gap-1.5 font-mono text-[11px] truncate text-neutral-700 dark:text-neutral-300">
                    <Key className="w-3 h-3 text-blue-600 dark:text-blue-400 shrink-0" />
                    <span className="truncate">{displayKey}</span>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => toggleReveal(api.id)}
                      className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
                      title={isRevealed ? 'Hide secret' : 'Reveal secret'}
                    >
                      {isRevealed ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    </button>
                    <button
                      onClick={(e) => handleCopyKeyOrUrl(e, api.apiKey, 'API Key', `${api.id}-key`)}
                      className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
                      title="Copy API Key"
                    >
                      {copiedId === `${api.id}-key` ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Actions Row: Clean Direct Redirect Button */}
            <div className="mt-4 pt-3 border-t border-neutral-100 dark:border-neutral-800/80 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                {api.rateLimit && (
                  <span className="text-[11px] text-neutral-400 font-mono">
                    {api.rateLimit}
                  </span>
                )}
              </div>

              {/* Direct Redirect to the site */}
              <a
                href={api.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-neutral-900 text-white dark:bg-blue-600 dark:text-white hover:bg-neutral-800 dark:hover:bg-blue-500 shadow-xs transition-all duration-150 group-hover:scale-[1.02]"
                title={`Redirect to ${api.name}`}
              >
                <span>Visit Site</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        );
      })}
    </div>
  );
};
