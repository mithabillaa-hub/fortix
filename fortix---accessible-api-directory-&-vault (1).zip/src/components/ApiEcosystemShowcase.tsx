import React, { useState, useRef, useEffect } from 'react';
import {
  ShieldCheck,
  Cpu,
  Database,
  Layers,
  ArrowUpRight,
  Server,
  Zap,
  Globe,
  Lock,
  Boxes,
  CheckCircle2,
  RefreshCw,
  Compass,
  Code2,
} from 'lucide-react';

interface ApiEcosystemShowcaseProps {
  totalApisCount: number;
  totalCategoriesCount: number;
  isDark?: boolean;
  onSelectCategory?: (category: string) => void;
  onExploreApis?: () => void;
}

export const ApiEcosystemShowcase: React.FC<ApiEcosystemShowcaseProps> = ({
  totalApisCount,
  totalCategoriesCount,
  isDark = false,
  onSelectCategory,
  onExploreApis,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0, normX: 0, normY: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const [activeHotspot, setActiveHotspot] = useState<'gateway' | 'containers' | 'apis'>('gateway');

  // Smooth mouse tilt handler
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const normX = ((x - rect.width / 2) / (rect.width / 2));
    const normY = ((y - rect.height / 2) / (rect.height / 2));
    setMousePos({ x, y, normX, normY });
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setMousePos({ x: 0, y: 0, normX: 0, normY: 0 });
  };

  // 3D rotation angles derived from normalized coordinates
  const rotateY = isHovered ? mousePos.normX * 8 : 0;
  const rotateX = isHovered ? -mousePos.normY * 6 : 0;

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={handleMouseLeave}
      className="relative w-full max-w-7xl mx-auto perspective-1400 select-none"
    >
      {/* Showroom Chrome Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-4 sm:px-6 py-2.5 text-[11px] font-mono uppercase tracking-wider border-b border-neutral-200 dark:border-neutral-800 bg-white/70 dark:bg-neutral-900/70 backdrop-blur-md rounded-t-2xl">
        <div className="flex items-center gap-2 text-neutral-500 dark:text-neutral-400">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="font-semibold text-neutral-900 dark:text-neutral-100">FORTIX SHOWROOM 01</span>
          <span aria-hidden="true" className="opacity-40">/</span>
          <span>VIRTUAL API ECOSYSTEM & CONTAINER MESH</span>
        </div>

        {/* Hotspot Switchers */}
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setActiveHotspot('containers')}
            className={`px-2.5 py-1 rounded-md text-[10px] font-medium transition-colors ${
              activeHotspot === 'containers'
                ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800'
                : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-200'
            }`}
          >
            01. Containers & DBs
          </button>
          <button
            type="button"
            onClick={() => setActiveHotspot('gateway')}
            className={`px-2.5 py-1 rounded-md text-[10px] font-medium transition-colors ${
              activeHotspot === 'gateway'
                ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800'
                : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-200'
            }`}
          >
            02. Central Gateway
          </button>
          <button
            type="button"
            onClick={() => setActiveHotspot('apis')}
            className={`px-2.5 py-1 rounded-md text-[10px] font-medium transition-colors ${
              activeHotspot === 'apis'
                ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800'
                : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-200'
            }`}
          >
            03. External APIs
          </button>
        </div>

        <div className="hidden md:flex items-center gap-2 text-neutral-400 dark:text-neutral-500">
          <Compass className="w-3.5 h-3.5" />
          <span>Interactive 3D Perspective</span>
        </div>
      </div>

      {/* Main 3D Perspective Stage Container */}
      <div
        style={{
          transform: `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`,
          transition: isHovered ? 'transform 0.08s ease-out' : 'transform 0.6s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
        className="relative preserve-3d w-full min-h-[460px] lg:min-h-[500px] rounded-b-2xl border-x border-b border-neutral-200 dark:border-neutral-800 bg-gradient-to-b from-neutral-50/90 via-white to-neutral-100/80 dark:from-[#0B0F19] dark:via-[#111827] dark:to-[#070A10] overflow-hidden shadow-2xl"
      >
        {/* Architectural Showroom Floor Grid */}
        <div
          aria-hidden="true"
          className="absolute inset-0 showroom-floor-grid opacity-60 pointer-events-none"
        />

        {/* Ambient Overhead Light Cone */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute top-0 left-1/2 -translate-x-1/2 w-[85%] h-[260px] bg-gradient-to-b from-blue-500/10 via-blue-500/5 to-transparent blur-2xl dark:from-blue-600/15 dark:via-blue-600/5"
        />

        {/* SVG Optical Data Conduit Beams */}
        <svg
          className="absolute inset-0 w-full h-full pointer-events-none z-10 hidden sm:block"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="beam-left-to-center" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#1D4ED8" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#0284C7" stopOpacity="0.9" />
            </linearGradient>
            <linearGradient id="beam-center-to-right" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#0284C7" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#2563EB" stopOpacity="0.8" />
            </linearGradient>
          </defs>

          {/* Left Container to Gateway Lines */}
          <path
            d="M 280 180 C 360 180, 420 220, 490 220"
            fill="none"
            stroke="url(#beam-left-to-center)"
            strokeWidth="2"
            className="animate-conduit opacity-80"
          />
          <path
            d="M 280 290 C 370 290, 420 260, 490 260"
            fill="none"
            stroke="url(#beam-left-to-center)"
            strokeWidth="2"
            className="animate-conduit opacity-70"
          />

          {/* Gateway to Right APIs Lines */}
          <path
            d="M 760 220 C 830 220, 890 180, 970 180"
            fill="none"
            stroke="url(#beam-center-to-right)"
            strokeWidth="2"
            className="animate-conduit opacity-80"
          />
          <path
            d="M 760 260 C 840 260, 890 290, 970 290"
            fill="none"
            stroke="url(#beam-center-to-right)"
            strokeWidth="2"
            className="animate-conduit opacity-70"
          />
        </svg>

        {/* 3-Column Architectural Showcase Layout */}
        <div className="relative z-20 grid grid-cols-1 md:grid-cols-12 gap-6 p-6 sm:p-8 lg:p-10 items-center min-h-[460px]">
          
          {/* ========================================================
              LEFT PANEL: CONTAINER RUNTIMES & DATABASES (translateZ: 24px)
             ======================================================== */}
          <div
            style={{
              transform: 'translateZ(26px)',
            }}
            className="md:col-span-4 space-y-3.5 transition-transform"
          >
            {/* Section Tag */}
            <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400 font-mono">
              <span className="flex items-center gap-1.5 font-semibold text-neutral-900 dark:text-neutral-200">
                <Boxes className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>01. CONTAINER RUNTIMES</span>
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300">
                ISOLATED
              </span>
            </div>

            {/* Container Item 1: Docker Microservices */}
            <div
              onClick={() => onSelectCategory?.('Developer Tools')}
              className="group p-3.5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-white/80 dark:bg-neutral-900/80 backdrop-blur-sm shadow-sm hover:border-blue-400 dark:hover:border-blue-600 hover:shadow-md transition-all cursor-pointer"
            >
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-blue-50 dark:bg-blue-950 flex items-center justify-center text-blue-600 dark:text-blue-400">
                    <Server className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-neutral-900 dark:text-neutral-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                      Docker Ingress Pods
                    </h4>
                    <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
                      14 Microservices · Port :8080
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  LIVE
                </span>
              </div>
            </div>

            {/* Container Item 2: PostgreSQL Database */}
            <div
              onClick={() => onSelectCategory?.('Data and Analytics')}
              className="group p-3.5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-white/80 dark:bg-neutral-900/80 backdrop-blur-sm shadow-sm hover:border-blue-400 dark:hover:border-blue-600 hover:shadow-md transition-all cursor-pointer"
            >
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-indigo-50 dark:bg-indigo-950 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
                    <Database className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-neutral-900 dark:text-neutral-100 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                      PostgreSQL Relational DB
                    </h4>
                    <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
                      {totalApisCount} Verified Endpoints indexed
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-mono text-neutral-500">
                  0.3ms
                </span>
              </div>
            </div>

            {/* Container Item 3: Redis Cache & Vector Store */}
            <div
              onClick={() => onSelectCategory?.('Artificial Intelligence')}
              className="group p-3.5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-white/80 dark:bg-neutral-900/80 backdrop-blur-sm shadow-sm hover:border-blue-400 dark:hover:border-blue-600 hover:shadow-md transition-all cursor-pointer"
            >
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-emerald-50 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                    <Zap className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-neutral-900 dark:text-neutral-100 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                      Redis In-Memory Cache
                    </h4>
                    <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
                      Key-Value Vault & Rate Limiting
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400">
                  99.9% HIT
                </span>
              </div>
            </div>
          </div>

          {/* ========================================================
              CENTER SHOWPIECE: CENTRAL API GATEWAY (translateZ: 44px)
             ======================================================== */}
          <div
            style={{
              transform: 'translateZ(46px)',
            }}
            className="md:col-span-4 flex flex-col items-center justify-center"
          >
            <div className="w-full max-w-sm rounded-2xl border-2 border-blue-500/40 dark:border-blue-400/30 bg-white/95 dark:bg-neutral-900/95 backdrop-blur-xl p-6 shadow-2xl relative overflow-hidden text-center group">
              {/* Subtle top spotlight bar */}
              <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-blue-600 via-sky-400 to-indigo-600" />

              {/* Gateway Core Icon */}
              <div className="mx-auto w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white flex items-center justify-center shadow-lg mb-4 ring-4 ring-blue-100 dark:ring-blue-950">
                <Cpu className="w-7 h-7 animate-pulse" />
              </div>

              {/* Title & Identity */}
              <div className="space-y-1">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-semibold bg-blue-50 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                  <ShieldCheck className="w-3 h-3" />
                  <span>ACTIVE GATEWAY CORE</span>
                </div>
                <h3 className="text-lg font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
                  FORTIX API GATEWAY
                </h3>
                <p className="text-xs text-neutral-500 dark:text-neutral-400 max-w-xs mx-auto">
                  Single ingress point for routing, authentication verification, and direct site redirection.
                </p>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-2 gap-2 mt-5 pt-4 border-t border-neutral-100 dark:border-neutral-800 text-left">
                <div className="p-2 rounded-lg bg-neutral-50 dark:bg-neutral-800/60">
                  <div className="text-[10px] text-neutral-500 dark:text-neutral-400 font-mono uppercase">
                    Throughput
                  </div>
                  <div className="text-sm font-bold text-neutral-900 dark:text-neutral-100 font-mono">
                    48.2k <span className="text-[10px] font-normal text-neutral-500">req/s</span>
                  </div>
                </div>

                <div className="p-2 rounded-lg bg-neutral-50 dark:bg-neutral-800/60">
                  <div className="text-[10px] text-neutral-500 dark:text-neutral-400 font-mono uppercase">
                    Ingress Latency
                  </div>
                  <div className="text-sm font-bold text-emerald-600 dark:text-emerald-400 font-mono">
                    1.2 <span className="text-[10px] font-normal text-neutral-500">ms</span>
                  </div>
                </div>

                <div className="p-2 rounded-lg bg-neutral-50 dark:bg-neutral-800/60">
                  <div className="text-[10px] text-neutral-500 dark:text-neutral-400 font-mono uppercase">
                    SSL Security
                  </div>
                  <div className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 flex items-center gap-1">
                    <Lock className="w-3 h-3 text-blue-600" />
                    TLS 1.3
                  </div>
                </div>

                <div className="p-2 rounded-lg bg-neutral-50 dark:bg-neutral-800/60">
                  <div className="text-[10px] text-neutral-500 dark:text-neutral-400 font-mono uppercase">
                    Catalog
                  </div>
                  <div className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 flex items-center gap-1">
                    <Globe className="w-3 h-3 text-blue-600" />
                    {totalApisCount} Endpoints
                  </div>
                </div>
              </div>

              {/* Quick Action */}
              <button
                type="button"
                onClick={onExploreApis}
                className="w-full mt-4 py-2 px-3 rounded-xl bg-neutral-900 text-white dark:bg-blue-600 dark:text-white hover:bg-neutral-800 dark:hover:bg-blue-500 text-xs font-semibold shadow-sm transition-colors flex items-center justify-center gap-1.5"
              >
                <span>EXPLORE DIRECTORY</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* ========================================================
              RIGHT PANEL: EXTERNAL APIS & INTEGRATIONS (translateZ: 24px)
             ======================================================== */}
          <div
            style={{
              transform: 'translateZ(26px)',
            }}
            className="md:col-span-4 space-y-3.5 transition-transform"
          >
            {/* Section Tag */}
            <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400 font-mono">
              <span className="flex items-center gap-1.5 font-semibold text-neutral-900 dark:text-neutral-200">
                <Globe className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                <span>02. EXTERNAL APIS & INTEGRATIONS</span>
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300">
                {totalCategoriesCount} DOMAINS
              </span>
            </div>

            {/* External Item 1: AI & LLMs */}
            <div
              onClick={() => onSelectCategory?.('Artificial Intelligence')}
              className="group p-3.5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-white/80 dark:bg-neutral-900/80 backdrop-blur-sm shadow-sm hover:border-blue-400 dark:hover:border-blue-600 hover:shadow-md transition-all cursor-pointer"
            >
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-sky-50 dark:bg-sky-950 flex items-center justify-center text-sky-600 dark:text-sky-400">
                    <Cpu className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-neutral-900 dark:text-neutral-100 group-hover:text-sky-600 dark:group-hover:text-sky-400 transition-colors">
                      AI & Large Language Models
                    </h4>
                    <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
                      OpenAI, Anthropic, Gemini, DeepSeek
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-mono text-blue-600 dark:text-blue-400">
                  BEARER
                </span>
              </div>
            </div>

            {/* External Item 2: Financial & Payments */}
            <div
              onClick={() => onSelectCategory?.('Finance')}
              className="group p-3.5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-white/80 dark:bg-neutral-900/80 backdrop-blur-sm shadow-sm hover:border-blue-400 dark:hover:border-blue-600 hover:shadow-md transition-all cursor-pointer"
            >
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-emerald-50 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                    <ShieldCheck className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-neutral-900 dark:text-neutral-100 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                      Finance & Payments
                    </h4>
                    <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
                      Stripe, Plaid, PayPal, CoinGecko
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-mono text-neutral-500">
                  KEY AUTH
                </span>
              </div>
            </div>

            {/* External Item 3: Maps & Communications */}
            <div
              onClick={() => onSelectCategory?.('Maps and Location')}
              className="group p-3.5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-white/80 dark:bg-neutral-900/80 backdrop-blur-sm shadow-sm hover:border-blue-400 dark:hover:border-blue-600 hover:shadow-md transition-all cursor-pointer"
            >
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-amber-50 dark:bg-amber-950 flex items-center justify-center text-amber-600 dark:text-amber-400">
                    <Globe className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-neutral-900 dark:text-neutral-100 group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors">
                      Maps, Media & Location
                    </h4>
                    <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
                      Google Maps, Mapbox, Twilio
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-mono text-neutral-500">
                  PUBLIC/CORS
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Status Ribbon */}
        <div className="relative z-20 px-6 py-3 border-t border-neutral-200/80 dark:border-neutral-800/80 bg-neutral-50/90 dark:bg-neutral-950/80 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-medium">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Gateway Ingress Healthy</span>
            </span>
            <span aria-hidden="true" className="text-neutral-300 dark:text-neutral-700">·</span>
            <span className="text-neutral-600 dark:text-neutral-400">
              Direct Site Redirections Enabled
            </span>
          </div>

          <div className="flex items-center gap-4 text-[11px] font-mono text-neutral-500 dark:text-neutral-400">
            <span>ROTATION: [ {rotateX.toFixed(1)}° X, {rotateY.toFixed(1)}° Y ]</span>
            <span aria-hidden="true">·</span>
            <span>CONTAINER ENGINE ACTIVE</span>
          </div>
        </div>
      </div>
    </div>
  );
};
