import React from 'react';
import { ArrowUpRight, Upload, RotateCcw, ShieldCheck, Sparkles, Layers, Cpu, Compass, Palette, Plus, Grid, LayoutGrid } from 'lucide-react';
import { ApiEcosystemShowcase } from './ApiEcosystemShowcase';
import { THEME_PALETTES } from '../utils/palettes';
import { ThemePaletteId } from '../types';

interface HeroBannerProps {
  totalApisCount: number;
  totalCategoriesCount: number;
  onOpenImportModal: () => void;
  onResetFortixApis: () => void;
  onOpenAddModal?: () => void;
  onSelectCategory?: (category: string) => void;
  isDark?: boolean;
  activePaletteId?: ThemePaletteId;
  onChangePalette?: (p: ThemePaletteId) => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  totalApisCount,
  totalCategoriesCount,
  onOpenImportModal,
  onResetFortixApis,
  onOpenAddModal,
  onSelectCategory,
  isDark = false,
  activePaletteId = 'cersanit',
  onChangePalette,
}) => {
  const currentPalette = THEME_PALETTES[activePaletteId] || THEME_PALETTES.cersanit;

  const scrollToDirectory = () => {
    const el = document.getElementById('api-directory-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative overflow-hidden pt-8 pb-14 sm:pt-12 sm:pb-20 px-4 sm:px-6 lg:px-8 border-b border-neutral-200 dark:border-neutral-800 bg-[#F8F9FA] dark:bg-[#0B0F19] transition-colors">
      {/* Subtle architectural ambient gradient */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-40 left-1/2 -translate-x-1/2 w-[1000px] h-[450px] bg-gradient-to-b from-blue-100/60 via-blue-50/20 to-transparent dark:from-blue-950/20 dark:via-blue-900/5 blur-3xl opacity-70"
      />

      <div className="relative max-w-7xl mx-auto space-y-10">
        {/* Editorial Header Block inspired by Cersanit composition */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          {/* Subtle Condensed Brand Kicker */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-[11px] font-mono tracking-widest uppercase bg-white dark:bg-neutral-900 text-neutral-600 dark:text-neutral-400 border border-neutral-200 dark:border-neutral-800 shadow-xs">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-600 dark:bg-blue-400" />
            <span className="font-semibold text-neutral-900 dark:text-neutral-100">FORTIX</span>
            <span aria-hidden="true" className="opacity-40">/</span>
            <span>API CONTAINER PLATFORM</span>
            <span aria-hidden="true" className="opacity-40">/</span>
            <span className="text-blue-600 dark:text-blue-400 font-semibold">{totalApisCount} ENDPOINTS</span>
          </div>

          {/* Main Architectural Headline */}
          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-[#0F172A] dark:text-white leading-[1.08] font-display">
            YOUR APIS.<br />
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-700 via-sky-600 to-indigo-700 dark:from-blue-400 dark:via-sky-300 dark:to-indigo-300">
              ONE UNIFIED SPACE.
            </span>
          </h1>

          {/* Supporting Prose */}
          <p className="text-sm sm:text-base text-neutral-600 dark:text-neutral-300 max-w-2xl mx-auto leading-relaxed">
            Discover powerful developer APIs, inspect container runtimes, copy authentication keys, and redirect straight to official live documentation through a centralized gateway.
          </p>

          {/* Primary Action Row */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={scrollToDirectory}
              className="px-6 py-2.5 rounded-xl text-xs font-semibold uppercase tracking-wider bg-neutral-900 text-white dark:bg-blue-600 dark:text-white hover:bg-neutral-800 dark:hover:bg-blue-500 shadow-md transition-all flex items-center gap-2 group"
            >
              <span>EXPLORE {totalApisCount} APIS</span>
              <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </button>

            {onOpenAddModal && (
              <button
                type="button"
                onClick={onOpenAddModal}
                className="px-4 py-2.5 rounded-xl text-xs font-medium uppercase tracking-wider bg-white dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300 border border-neutral-200 dark:border-neutral-800 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                <span>ADD API</span>
              </button>
            )}

            <button
              type="button"
              onClick={onResetFortixApis}
              className="p-2.5 rounded-xl text-xs text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 border border-neutral-200 dark:border-neutral-800 hover:bg-white dark:hover:bg-neutral-900 transition-colors"
              title="Reset default 800+ Fortix dataset"
              aria-label="Reset default dataset"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 3D SHOWROOM CENTERPIECE: Wide Perspective API Ecosystem */}
        <div className="pt-2">
          <ApiEcosystemShowcase
            totalApisCount={totalApisCount}
            totalCategoriesCount={totalCategoriesCount}
            isDark={isDark}
            onSelectCategory={onSelectCategory}
            onExploreApis={scrollToDirectory}
          />
        </div>

        {/* Cersanit Architectural 4-Pillar Spec Strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-neutral-200/80 dark:border-neutral-800/80 max-w-5xl mx-auto">
          <div className="p-3.5 rounded-xl bg-white/70 dark:bg-neutral-900/60 border border-neutral-200/80 dark:border-neutral-800/80 text-center space-y-1">
            <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-500 dark:text-neutral-400">
              Direct Redirect
            </span>
            <div className="text-sm font-bold text-neutral-900 dark:text-neutral-100 font-display">
              1-Click Live Sites
            </div>
            <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
              No dead clicks, opens official APIs
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-white/70 dark:bg-neutral-900/60 border border-neutral-200/80 dark:border-neutral-800/80 text-center space-y-1">
            <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-500 dark:text-neutral-400">
              Category Mesh
            </span>
            <div className="text-sm font-bold text-neutral-900 dark:text-neutral-100 font-display">
              {totalCategoriesCount} Specialized Windows
            </div>
            <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
              Interactive 3D depth & parallax
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-white/70 dark:bg-neutral-900/60 border border-neutral-200/80 dark:border-neutral-800/80 text-center space-y-1">
            <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-500 dark:text-neutral-400">
              Key Security
            </span>
            <div className="text-sm font-bold text-neutral-900 dark:text-neutral-100 font-display">
              Mask / Reveal Vault
            </div>
            <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
              Client-encrypted localStorage
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-white/70 dark:bg-neutral-900/60 border border-neutral-200/80 dark:border-neutral-800/80 text-center space-y-1">
            <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-500 dark:text-neutral-400">
              Gateway Ingress
            </span>
            <div className="text-sm font-bold text-neutral-900 dark:text-neutral-100 font-display">
              1.2ms Verification
            </div>
            <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
              CORS, Bearer & Header checks
            </p>
          </div>
        </div>

        {/* Minimal Palette Switcher for Personalization */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
          <span className="text-[11px] font-mono uppercase tracking-wider text-neutral-500 dark:text-neutral-400 flex items-center gap-1.5 mr-1">
            <Palette className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            <span>PALETTE:</span>
          </span>

          {Object.values(THEME_PALETTES).map((p) => {
            const isActive = p.id === activePaletteId;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => onChangePalette?.(p.id)}
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono transition-all border ${
                  isActive
                    ? 'border-blue-600 dark:border-blue-400 bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-xs font-semibold'
                    : 'border-neutral-200 dark:border-neutral-800 bg-white/70 dark:bg-neutral-900/60 text-neutral-600 dark:text-neutral-400 hover:border-neutral-300'
                }`}
              >
                <div className="flex items-center -space-x-1">
                  {p.colors.slice(0, 3).map((c, i) => (
                    <span
                      key={i}
                      className="w-2.5 h-2.5 rounded-full border border-black/10"
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
                <span>{p.name.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};
