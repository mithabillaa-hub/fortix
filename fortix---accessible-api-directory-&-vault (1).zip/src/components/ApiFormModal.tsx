import React, { useState, useEffect } from 'react';
import { ApiItem, AuthType, ApiStatus } from '../types';
import { X, Eye, EyeOff, Save, Sparkles } from 'lucide-react';

interface ApiFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (item: ApiItem) => void;
  editingItem: ApiItem | null;
  existingCategories: string[];
}

export const ApiFormModal: React.FC<ApiFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingItem,
  existingCategories,
}) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState('');
  const [url, setUrl] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [authType, setAuthType] = useState<AuthType>('bearer');
  const [headerKey, setHeaderKey] = useState('Authorization');
  const [queryParamKey, setQueryParamKey] = useState('key');
  const [docsUrl, setDocsUrl] = useState('');
  const [description, setDescription] = useState('');
  const [tagsStr, setTagsStr] = useState('');
  const [status, setStatus] = useState<ApiStatus>('active');
  const [rateLimit, setRateLimit] = useState('');
  const [notes, setNotes] = useState('');
  const [showKey, setShowKey] = useState(false);

  useEffect(() => {
    if (editingItem) {
      setName(editingItem.name);
      setCategory(editingItem.category);
      setUrl(editingItem.url);
      setApiKey(editingItem.apiKey);
      setAuthType(editingItem.authType);
      setHeaderKey(editingItem.headerKey || (editingItem.authType === 'bearer' ? 'Authorization' : 'x-api-key'));
      setQueryParamKey(editingItem.queryParamKey || 'key');
      setDocsUrl(editingItem.docsUrl || '');
      setDescription(editingItem.description);
      setTagsStr(editingItem.tags.join(', '));
      setStatus(editingItem.status);
      setRateLimit(editingItem.rateLimit || '');
      setNotes(editingItem.notes || '');
    } else {
      setName('');
      setCategory(existingCategories[0] || 'Artificial Intelligence');
      setUrl('https://api.');
      setApiKey('');
      setAuthType('bearer');
      setHeaderKey('Authorization');
      setQueryParamKey('key');
      setDocsUrl('');
      setDescription('');
      setTagsStr('');
      setStatus('active');
      setRateLimit('');
      setNotes('');
    }
  }, [editingItem, isOpen, existingCategories]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const tags = tagsStr
      .split(',')
      .map(t => t.trim())
      .filter(Boolean);

    const savedItem: ApiItem = {
      id: editingItem ? editingItem.id : `api-${Date.now()}`,
      name: name.trim(),
      category: category.trim() || 'General',
      url: url.trim() || 'https://',
      apiKey: apiKey.trim(),
      authType,
      headerKey: authType === 'bearer' || authType === 'header' || authType === 'basic' ? headerKey.trim() : undefined,
      queryParamKey: authType === 'query' ? queryParamKey.trim() : undefined,
      docsUrl: docsUrl.trim() || undefined,
      description: description.trim() || `API endpoint for ${name.trim()}`,
      tags: tags.length > 0 ? tags : [category.toLowerCase()],
      status,
      rateLimit: rateLimit.trim() || undefined,
      notes: notes.trim() || undefined,
      isFavorite: editingItem ? editingItem.isFavorite : false,
      createdAt: editingItem ? editingItem.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onSave(savedItem);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-900/60 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-api-form-title"
    >
      <div className="relative w-full max-w-2xl max-h-[90vh] flex flex-col bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 dark:border-neutral-800">
          <div>
            <h2 id="modal-api-form-title" className="text-lg font-semibold text-neutral-900 dark:text-neutral-100">
              {editingItem ? 'Edit API Entry' : 'Add New API Entry'}
            </h2>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
              Specify endpoint, credentials, documentation link, and categories.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded-lg transition-colors"
            aria-label="Close form"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto px-6 py-5 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Name */}
            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                API / Service Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. OpenAI, Stripe, WeatherStack"
                className="w-full text-xs px-3 py-2 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 focus:outline-hidden focus:ring-2 focus:ring-neutral-900 dark:focus:ring-neutral-100"
              />
            </div>

            {/* Category */}
            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                Category <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                list="category-suggestions"
                required
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                placeholder="e.g. Artificial Intelligence, Payments"
                className="w-full text-xs px-3 py-2 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 focus:outline-hidden focus:ring-2 focus:ring-neutral-900 dark:focus:ring-neutral-100"
              />
              <datalist id="category-suggestions">
                {existingCategories.map((c) => (
                  <option key={c} value={c} />
                ))}
              </datalist>
            </div>
          </div>

          {/* Endpoint URL */}
          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
              Base URL / Endpoint <span className="text-rose-500">*</span>
            </label>
            <input
              type="url"
              required
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://api.example.com/v1"
              className="w-full font-mono text-xs px-3 py-2 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 focus:outline-hidden focus:ring-2 focus:ring-neutral-900 dark:focus:ring-neutral-100"
            />
          </div>

          {/* API Key & Reveal toggle */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-semibold text-neutral-700 dark:text-neutral-300">
                API Key / Token / Secret
              </label>
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="text-[11px] text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200 inline-flex items-center gap-1"
              >
                {showKey ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                <span>{showKey ? 'Hide key' : 'Show key'}</span>
              </button>
            </div>
            <input
              type={showKey ? 'text' : 'password'}
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="e.g. sk-live_98129381..."
              className="w-full font-mono text-xs px-3 py-2 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 focus:outline-hidden focus:ring-2 focus:ring-neutral-900 dark:focus:ring-neutral-100"
            />
          </div>

          {/* Auth Type & Custom Key */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                Auth Method
              </label>
              <select
                value={authType}
                onChange={(e) => {
                  const val = e.target.value as AuthType;
                  setAuthType(val);
                  if (val === 'bearer') setHeaderKey('Authorization');
                  else if (val === 'header') setHeaderKey('x-api-key');
                  else if (val === 'query') setQueryParamKey('key');
                }}
                className="w-full text-xs px-3 py-2 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 focus:outline-hidden focus:ring-2 focus:ring-neutral-900 dark:focus:ring-neutral-100"
              >
                <option value="bearer">Bearer Token (Authorization: Bearer ...)</option>
                <option value="header">Custom Header (e.g. x-api-key)</option>
                <option value="query">Query Parameter (?key=...)</option>
                <option value="basic">HTTP Basic Auth (user:pass)</option>
                <option value="oauth2">OAuth 2.0</option>
                <option value="none">Public / No Auth Required</option>
              </select>
            </div>

            {authType === 'header' && (
              <div>
                <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                  Header Name
                </label>
                <input
                  type="text"
                  value={headerKey}
                  onChange={(e) => setHeaderKey(e.target.value)}
                  placeholder="e.g. x-api-key, apikey, X-Auth-Token"
                  className="w-full font-mono text-xs px-3 py-2 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 focus:outline-hidden"
                />
              </div>
            )}

            {authType === 'query' && (
              <div>
                <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                  Query Parameter Key
                </label>
                <input
                  type="text"
                  value={queryParamKey}
                  onChange={(e) => setQueryParamKey(e.target.value)}
                  placeholder="e.g. key, api_key, appid, access_token"
                  className="w-full font-mono text-xs px-3 py-2 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 focus:outline-hidden"
                />
              </div>
            )}
          </div>

          {/* Docs URL & Status */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                Documentation URL
              </label>
              <input
                type="url"
                value={docsUrl}
                onChange={(e) => setDocsUrl(e.target.value)}
                placeholder="https://docs.example.com"
                className="w-full text-xs px-3 py-2 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                Status
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as ApiStatus)}
                className="w-full text-xs px-3 py-2 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 focus:outline-hidden"
              >
                <option value="active">Active</option>
                <option value="testing">Testing / Sandbox</option>
                <option value="deprecated">Deprecated</option>
                <option value="expired">Expired</option>
              </select>
            </div>
          </div>

          {/* Rate Limit & Tags */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                Rate Limit / Quota
              </label>
              <input
                type="text"
                value={rateLimit}
                onChange={(e) => setRateLimit(e.target.value)}
                placeholder="e.g. 60 req/min, 100k/month"
                className="w-full text-xs px-3 py-2 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                Tags (comma separated)
              </label>
              <input
                type="text"
                value={tagsStr}
                onChange={(e) => setTagsStr(e.target.value)}
                placeholder="e.g. payments, webhook, v2"
                className="w-full text-xs px-3 py-2 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 focus:outline-hidden"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
              Description / Summary
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief summary of API capability"
              className="w-full text-xs px-3 py-2 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 focus:outline-hidden"
            />
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
              Personal Notes & Implementation Details
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Production account in AWS us-east-1, webhook signing key..."
              className="w-full text-xs p-3 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 focus:outline-hidden"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-200 dark:border-neutral-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-neutral-700 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-neutral-100 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg text-white bg-neutral-900 dark:bg-neutral-100 dark:text-neutral-900 hover:bg-neutral-800 dark:hover:bg-white transition-colors"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{editingItem ? 'Save Changes' : 'Create Entry'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
