import React, { useState } from 'react';
import { ApiItem } from '../types';
import { exportDatasetToJson, exportDatasetToCsv, exportDatasetToEnv } from '../utils/datasetParsers';
import { X, Copy, Download, Check, ShieldCheck, ShieldAlert } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: ApiItem[];
  onNotify: (msg: string) => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  items,
  onNotify,
}) => {
  const [format, setFormat] = useState<'json' | 'csv' | 'env'>('json');
  const [includeKeys, setIncludeKeys] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const getContent = () => {
    if (format === 'json') return exportDatasetToJson(items, includeKeys);
    if (format === 'csv') return exportDatasetToCsv(items, includeKeys);
    return exportDatasetToEnv(items);
  };

  const content = getContent();

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    onNotify(`Copied ${format.toUpperCase()} dataset to clipboard!`);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const ext = format === 'env' ? 'env' : format;
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `fortix-dataset-${new Date().toISOString().slice(0, 10)}.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
    onNotify(`Downloaded dataset as .${ext}`);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-900/60 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-export-title"
    >
      <div className="relative w-full max-w-2xl max-h-[90vh] flex flex-col bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 dark:border-neutral-800">
          <div>
            <h2 id="modal-export-title" className="text-lg font-semibold text-neutral-900 dark:text-neutral-100">
              Export API Dataset
            </h2>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
              Export {items.length} records to JSON, CSV, or .env format.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded-lg transition-colors"
            aria-label="Close export dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-4">
          {/* Format selection */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-1 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-lg text-xs">
              <button
                type="button"
                onClick={() => setFormat('json')}
                className={`px-3 py-1.5 font-medium rounded-md transition-colors ${
                  format === 'json'
                    ? 'bg-white dark:bg-neutral-700 text-neutral-900 dark:text-white shadow-xs'
                    : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100'
                }`}
              >
                JSON Array
              </button>
              <button
                type="button"
                onClick={() => setFormat('csv')}
                className={`px-3 py-1.5 font-medium rounded-md transition-colors ${
                  format === 'csv'
                    ? 'bg-white dark:bg-neutral-700 text-neutral-900 dark:text-white shadow-xs'
                    : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100'
                }`}
              >
                CSV Table
              </button>
              <button
                type="button"
                onClick={() => setFormat('env')}
                className={`px-3 py-1.5 font-medium rounded-md transition-colors ${
                  format === 'env'
                    ? 'bg-white dark:bg-neutral-700 text-neutral-900 dark:text-white shadow-xs'
                    : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100'
                }`}
              >
                .env Config
              </button>
            </div>

            {format !== 'env' && (
              <label className="flex items-center gap-2 cursor-pointer text-xs text-neutral-700 dark:text-neutral-300">
                <input
                  type="checkbox"
                  checked={includeKeys}
                  onChange={(e) => setIncludeKeys(e.target.checked)}
                  className="rounded-sm"
                />
                <span className="flex items-center gap-1 font-medium">
                  {includeKeys ? (
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-500" />
                  ) : (
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                  )}
                  {includeKeys ? 'Include raw secrets' : 'Mask secrets (Safe)'}
                </span>
              </label>
            )}
          </div>

          {/* Code Viewer */}
          <div className="relative">
            <pre className="font-mono text-xs p-3.5 max-h-72 overflow-auto rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950 text-neutral-800 dark:text-neutral-200 whitespace-pre">
              {content}
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950">
          <div className="text-xs text-neutral-500 dark:text-neutral-400">
            {items.length} records ready
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopy}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium border border-neutral-300 dark:border-neutral-700 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy to Clipboard'}</span>
            </button>
            <button
              type="button"
              onClick={handleDownload}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg text-white bg-neutral-900 dark:bg-neutral-100 dark:text-neutral-900 hover:bg-neutral-800 dark:hover:bg-white transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download File</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
