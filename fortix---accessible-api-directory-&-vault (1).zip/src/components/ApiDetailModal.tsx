import React, { useState } from 'react';
import { ApiItem, TestResult } from '../types';
import { generateCurlSnippet, generateJsSnippet, generatePythonSnippet, generateGoSnippet } from '../utils/codeGenerators';
import { X, ExternalLink, Copy, Check, Play, Code2, Shield, Eye, EyeOff, Terminal, Clock, RefreshCw } from 'lucide-react';

interface ApiDetailModalProps {
  api: ApiItem | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (api: ApiItem) => void;
  onNotify: (msg: string) => void;
}

export const ApiDetailModal: React.FC<ApiDetailModalProps> = ({
  api,
  isOpen,
  onClose,
  onEdit,
  onNotify,
}) => {
  const [activeTab, setActiveTab] = useState<'tester' | 'snippets' | 'details'>('tester');
  const [snippetLang, setSnippetLang] = useState<'curl' | 'js' | 'python' | 'go'>('curl');
  const [showKey, setShowKey] = useState(false);
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedSnippet, setCopiedSnippet] = useState(false);

  // Tester state
  const [testMethod, setTestMethod] = useState<'GET' | 'POST' | 'HEAD'>('GET');
  const [testUrl, setTestUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [testResult, setTestResult] = useState<TestResult | null>(null);

  // When API changes, initialize tester URL
  React.useEffect(() => {
    if (api) {
      setTestUrl(api.url);
      setTestResult(null);
      setShowKey(false);
    }
  }, [api]);

  if (!isOpen || !api) return null;

  const handleCopyKey = () => {
    if (!api.apiKey) return;
    navigator.clipboard.writeText(api.apiKey);
    setCopiedKey(true);
    onNotify(`Copied API Key for ${api.name}`);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  const handleCopyHeader = () => {
    let headerText = '';
    if (api.authType === 'bearer') {
      headerText = `Authorization: Bearer ${api.apiKey}`;
    } else if (api.authType === 'header') {
      headerText = `${api.headerKey || 'x-api-key'}: ${api.apiKey}`;
    } else if (api.authType === 'query') {
      headerText = `?${api.queryParamKey || 'key'}=${api.apiKey}`;
    } else {
      headerText = api.apiKey;
    }
    navigator.clipboard.writeText(headerText);
    onNotify(`Copied auth string to clipboard`);
  };

  const handleRunTest = async () => {
    if (!testUrl) return;
    setIsLoading(true);
    setTestResult(null);
    const startTime = performance.now();

    try {
      // Prepare request headers
      const headers: Record<string, string> = {
        Accept: 'application/json',
      };
      let fetchUrl = testUrl;

      if (api.authType === 'bearer' && api.apiKey) {
        headers['Authorization'] = `Bearer ${api.apiKey}`;
      } else if (api.authType === 'header' && api.apiKey) {
        headers[api.headerKey || 'x-api-key'] = api.apiKey;
      } else if (api.authType === 'query' && api.apiKey) {
        const sep = fetchUrl.includes('?') ? '&' : '?';
        fetchUrl = `${fetchUrl}${sep}${api.queryParamKey || 'key'}=${api.apiKey}`;
      }

      const response = await fetch(fetchUrl, {
        method: testMethod,
        headers,
      });

      const endTime = performance.now();
      const timeMs = Math.round(endTime - startTime);

      let data: unknown;
      const contentType = response.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        data = await response.json();
      } else {
        data = await response.text();
      }

      const resHeaders: Record<string, string> = {};
      response.headers.forEach((val, key) => {
        resHeaders[key] = val;
      });

      setTestResult({
        status: response.status,
        statusText: response.statusText,
        timeMs,
        data,
        headers: resHeaders,
        isError: !response.ok,
      });
    } catch (err: unknown) {
      const endTime = performance.now();
      const isCors = err instanceof TypeError && String(err.message).toLowerCase().includes('failed to fetch');

      setTestResult({
        status: isCors ? 0 : 500,
        statusText: isCors ? 'CORS Restricted (Browser constraint)' : 'Connection Failed',
        timeMs: Math.round(endTime - startTime),
        data: isCors
          ? {
              info: 'The target API does not allow direct cross-origin browser fetches (CORS).',
              recommendation: 'Use the cURL snippet in your terminal or backend server to execute directly with no CORS barrier.',
              endpoint: testUrl,
              testedWithKey: api.apiKey ? `${api.apiKey.slice(0, 4)}••••` : 'None',
            }
          : { error: err instanceof Error ? err.message : 'Unknown network failure' },
        headers: {},
        isError: true,
        corsBlocked: isCors,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSimulateMock = () => {
    setIsLoading(true);
    setTimeout(() => {
      setTestResult({
        status: 200,
        statusText: '200 OK (Simulated Response)',
        timeMs: 42,
        data: {
          success: true,
          provider: api.name,
          category: api.category,
          status: 'healthy',
          auth_valid: Boolean(api.apiKey),
          latency_benchmark: '42ms',
          mock_payload: {
            timestamp: new Date().toISOString(),
            rateLimitRemaining: api.rateLimit || '95/100',
            message: 'Endpoint reachability verified in simulation mode.',
          },
        },
        headers: {
          'content-type': 'application/json',
          'x-powered-by': 'Fortix Health Prober',
        },
        isError: false,
      });
      setIsLoading(false);
    }, 400);
  };

  const getActiveSnippet = () => {
    if (snippetLang === 'curl') return generateCurlSnippet(api);
    if (snippetLang === 'js') return generateJsSnippet(api);
    if (snippetLang === 'python') return generatePythonSnippet(api);
    return generateGoSnippet(api);
  };

  const handleCopySnippet = () => {
    navigator.clipboard.writeText(getActiveSnippet());
    setCopiedSnippet(true);
    onNotify(`Copied ${snippetLang.toUpperCase()} snippet`);
    setTimeout(() => setCopiedSnippet(false), 2000);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-900/60 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-api-detail-title"
    >
      <div className="relative w-full max-w-4xl max-h-[92vh] flex flex-col bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-start justify-between px-6 py-4 border-b border-neutral-200 dark:border-neutral-800">
          <div>
            <div className="flex items-center gap-2">
              <h2 id="modal-api-detail-title" className="text-lg font-bold text-neutral-900 dark:text-neutral-100">
                {api.name}
              </h2>
              <span className="text-xs text-neutral-500 dark:text-neutral-400">
                · {api.category} · {api.authType.toUpperCase()}
              </span>
            </div>
            <p className="text-xs text-neutral-600 dark:text-neutral-400 mt-1 max-w-2xl">
              {api.description}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <a
              href={api.url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-neutral-900 text-white dark:bg-[#FFA586] dark:text-[#16152F] hover:bg-neutral-800 dark:hover:bg-[#ffb59c] shadow-xs transition-colors"
            >
              <span>Visit Site</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
            <button
              onClick={() => onEdit(api)}
              className="px-3 py-1.5 text-xs font-medium border border-neutral-300 dark:border-neutral-700 rounded-xl hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors text-neutral-700 dark:text-neutral-200"
            >
              Edit Entry
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded-lg transition-colors"
              aria-label="Close API inspector"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Key Quick Bar */}
        <div className="px-6 py-3 bg-neutral-50 dark:bg-neutral-950/70 border-b border-neutral-200 dark:border-neutral-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 font-mono">
            <Shield className="w-3.5 h-3.5 text-neutral-500" />
            <span className="text-neutral-500 dark:text-neutral-400">Key:</span>
            <span className="font-semibold text-neutral-900 dark:text-neutral-100">
              {showKey ? api.apiKey || 'No key set' : api.apiKey ? `${api.apiKey.slice(0, 4)}••••••••••••${api.apiKey.slice(-4)}` : 'None'}
            </span>
            {api.apiKey && (
              <button
                onClick={() => setShowKey(!showKey)}
                className="text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 p-0.5 ml-1"
                title={showKey ? 'Mask key' : 'Reveal key'}
              >
                {showKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            {api.apiKey && (
              <>
                <button
                  onClick={handleCopyKey}
                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium border border-neutral-200 dark:border-neutral-700 rounded-md hover:bg-white dark:hover:bg-neutral-800 transition-colors"
                >
                  {copiedKey ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedKey ? 'Copied' : 'Copy Key'}</span>
                </button>
                <button
                  onClick={handleCopyHeader}
                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium border border-neutral-200 dark:border-neutral-700 rounded-md hover:bg-white dark:hover:bg-neutral-800 transition-colors"
                >
                  <Copy className="w-3 h-3" />
                  <span>Copy Auth Header</span>
                </button>
              </>
            )}
            {api.docsUrl && (
              <a
                href={api.docsUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-neutral-700 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-neutral-100 hover:underline"
              >
                <span>Documentation</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>
        </div>

        {/* Tab Bar */}
        <div className="flex items-center gap-1 px-6 pt-3 border-b border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900">
          <button
            onClick={() => setActiveTab('tester')}
            className={`px-3 py-2 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'tester'
                ? 'border-neutral-900 dark:border-neutral-100 text-neutral-900 dark:text-neutral-100'
                : 'border-transparent text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-100'
            }`}
          >
            Live Endpoint Tester
          </button>
          <button
            onClick={() => setActiveTab('snippets')}
            className={`px-3 py-2 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'snippets'
                ? 'border-neutral-900 dark:border-neutral-100 text-neutral-900 dark:text-neutral-100'
                : 'border-transparent text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-100'
            }`}
          >
            Code Snippets
          </button>
          <button
            onClick={() => setActiveTab('details')}
            className={`px-3 py-2 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'details'
                ? 'border-neutral-900 dark:border-neutral-100 text-neutral-900 dark:text-neutral-100'
                : 'border-transparent text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-100'
            }`}
          >
            Full Details & Metadata
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {activeTab === 'tester' && (
            <div className="space-y-4">
              {/* Request URL & Method */}
              <div className="flex items-center gap-2">
                <select
                  value={testMethod}
                  onChange={(e) => setTestMethod(e.target.value as 'GET' | 'POST' | 'HEAD')}
                  className="text-xs font-mono font-semibold px-2.5 py-2 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 focus:outline-hidden"
                >
                  <option value="GET">GET</option>
                  <option value="POST">POST</option>
                  <option value="HEAD">HEAD</option>
                </select>

                <input
                  type="text"
                  value={testUrl}
                  onChange={(e) => setTestUrl(e.target.value)}
                  placeholder="https://api.example.com/v1"
                  className="flex-1 font-mono text-xs px-3 py-2 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 focus:outline-hidden"
                />

                <button
                  type="button"
                  disabled={isLoading}
                  onClick={handleRunTest}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg text-white bg-neutral-900 dark:bg-neutral-100 dark:text-neutral-900 hover:bg-neutral-800 dark:hover:bg-white disabled:opacity-50 transition-colors shrink-0"
                >
                  {isLoading ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Play className="w-3.5 h-3.5 fill-current" />
                  )}
                  <span>{isLoading ? 'Executing...' : 'Send Request'}</span>
                </button>
              </div>

              {/* Response Panel */}
              {testResult && (
                <div className="space-y-2 border border-neutral-200 dark:border-neutral-800 rounded-lg p-4 bg-neutral-50 dark:bg-neutral-950">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2.5">
                      <span
                        className={`font-mono font-bold ${
                          testResult.status && testResult.status >= 200 && testResult.status < 300
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : 'text-amber-600 dark:text-amber-400'
                        }`}
                      >
                        Status: {testResult.status || 'ERR'} {testResult.statusText}
                      </span>
                      <span className="text-neutral-500">·</span>
                      <span className="flex items-center gap-1 font-mono tabular-nums text-neutral-600 dark:text-neutral-400">
                        <Clock className="w-3 h-3" />
                        {testResult.timeMs} ms
                      </span>
                    </div>

                    {testResult.corsBlocked && (
                      <button
                        onClick={handleSimulateMock}
                        className="text-xs text-blue-600 dark:text-blue-400 hover:underline font-medium"
                      >
                        Run Mock Prober Simulation →
                      </button>
                    )}
                  </div>

                  <div className="mt-2">
                    <pre className="font-mono text-xs p-3 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 max-h-72 overflow-auto whitespace-pre-wrap">
                      {typeof testResult.data === 'string'
                        ? testResult.data
                        : JSON.stringify(testResult.data, null, 2)}
                    </pre>
                  </div>
                </div>
              )}

              {!testResult && (
                <div className="text-center py-8 text-neutral-500 dark:text-neutral-400 text-xs">
                  Click <strong className="text-neutral-800 dark:text-neutral-200">Send Request</strong> to test the endpoint, inspect latency, or verify header formatting.
                </div>
              )}
            </div>
          )}

          {activeTab === 'snippets' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-lg text-xs">
                  {(['curl', 'js', 'python', 'go'] as const).map((lang) => (
                    <button
                      key={lang}
                      onClick={() => setSnippetLang(lang)}
                      className={`px-3 py-1 font-medium rounded-md uppercase text-[11px] transition-colors ${
                        snippetLang === lang
                          ? 'bg-white dark:bg-neutral-700 text-neutral-900 dark:text-white shadow-xs'
                          : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100'
                      }`}
                    >
                      {lang === 'js' ? 'JavaScript' : lang}
                    </button>
                  ))}
                </div>

                <button
                  onClick={handleCopySnippet}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-neutral-300 dark:border-neutral-700 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                >
                  {copiedSnippet ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSnippet ? 'Copied' : 'Copy Snippet'}</span>
                </button>
              </div>

              <div className="relative">
                <pre className="font-mono text-xs p-4 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-950 text-neutral-100 max-h-80 overflow-auto whitespace-pre">
                  {getActiveSnippet()}
                </pre>
              </div>
            </div>
          )}

          {activeTab === 'details' && (
            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="border border-neutral-200 dark:border-neutral-800 p-3.5 rounded-lg space-y-2">
                  <span className="font-semibold text-neutral-900 dark:text-neutral-100 block">General Info</span>
                  <div className="space-y-1 text-neutral-600 dark:text-neutral-400">
                    <div>Category: <span className="text-neutral-900 dark:text-neutral-100 font-medium">{api.category}</span></div>
                    <div>Status: <span className="text-neutral-900 dark:text-neutral-100 font-medium">{api.status}</span></div>
                    <div>Rate Limit: <span className="text-neutral-900 dark:text-neutral-100 font-medium">{api.rateLimit || 'Not specified'}</span></div>
                    <div>Created: <span className="font-mono tabular-nums">{new Date(api.createdAt).toLocaleDateString()}</span></div>
                  </div>
                </div>

                <div className="border border-neutral-200 dark:border-neutral-800 p-3.5 rounded-lg space-y-2">
                  <span className="font-semibold text-neutral-900 dark:text-neutral-100 block">Authentication Schema</span>
                  <div className="space-y-1 text-neutral-600 dark:text-neutral-400">
                    <div>Type: <span className="text-neutral-900 dark:text-neutral-100 font-medium">{api.authType}</span></div>
                    <div>Header Key: <span className="font-mono text-neutral-900 dark:text-neutral-100">{api.headerKey || 'None'}</span></div>
                    <div>Query Param: <span className="font-mono text-neutral-900 dark:text-neutral-100">{api.queryParamKey || 'None'}</span></div>
                    <div>Has Secret Key: <span className="text-neutral-900 dark:text-neutral-100 font-medium">{api.apiKey ? 'Yes' : 'No'}</span></div>
                  </div>
                </div>
              </div>

              {api.notes && (
                <div className="border border-neutral-200 dark:border-neutral-800 p-3.5 rounded-lg">
                  <span className="font-semibold text-neutral-900 dark:text-neutral-100 block mb-1">Notes & Instructions</span>
                  <p className="text-neutral-600 dark:text-neutral-300 whitespace-pre-wrap">{api.notes}</p>
                </div>
              )}

              {api.tags.length > 0 && (
                <div>
                  <span className="font-semibold text-neutral-900 dark:text-neutral-100 block mb-1">Tags</span>
                  <div className="flex flex-wrap gap-2 text-neutral-500 dark:text-neutral-400 text-xs">
                    {api.tags.map((t, i) => (
                      <span key={t}>
                        #{t} {i < api.tags.length - 1 && '·'}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
