import React from 'react';
import { FilterState, SortField, SortOrder } from '../types';
import { Star, RotateCcw, ArrowUpDown, ShieldCheck, Globe } from 'lucide-react';

interface FilterBarProps {
  categories: { name: string; count: number }[];
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
  httpsOnly: boolean;
  onToggleHttpsOnly: () => void;
  corsOnly: boolean;
  onToggleCorsOnly: () => void;
  totalFilteredCount: number;
  totalAllCount: number;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  categories,
  filters,
  onFilterChange,
  httpsOnly,
  onToggleHttpsOnly,
  corsOnly,
  onToggleCorsOnly,
  totalFilteredCount,
  totalAllCount,
}) => {
  const isAnyFilterActive =
    filters.category !== 'all' ||
    filters.authType !== 'all' ||
    filters.status !== 'all' ||
    filters.onlyFavorites ||
    httpsOnly ||
    corsOnly ||
    filters.search !== '';

  const handleResetFilters = () => {
    onFilterChange({
      ...filters,
      category: 'all',
      authType: 'all',
      status: 'all',
      onlyFavorites: false,
      search: '',
    });
    if (httpsOnly) onToggleHttpsOnly();
    if (corsOnly) onToggleCorsOnly();
  };

  return (
    <div
      id="api-directory-section"
      className="w-full bg-white dark:bg-[#0B0F19] border-b border-neutral-200/90 dark:border-neutral-800/90 py-4 px-4 sm:px-6 lg:px-8 space-y-3.5 transition-colors"
    >
      {/* Categories horizontal scroll tabs (Architectural Cersanit Clean Navigation) */}
      <div
        className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none"
        role="tablist"
        aria-label="API Categories"
      >
        <button
          role="tab"
          aria-selected={filters.category === 'all'}
          onClick={() => onFilterChange({ ...filters, category: 'all' })}
          className={`shrink-0 px-3.5 py-1.5 text-xs uppercase tracking-wider font-medium rounded-lg transition-all flex items-center gap-1.5 ${
            filters.category === 'all'
              ? 'bg-neutral-900 text-white dark:bg-blue-600 dark:text-white shadow-xs font-semibold'
              : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800/60'
          }`}
        >
          <span>All Categories</span>
          <span className="text-[10px] font-mono opacity-70 tabular-nums">({totalAllCount})</span>
        </button>

        {categories.map((cat) => {
          const isSelected = filters.category === cat.name;
          return (
            <button
              key={cat.name}
              role="tab"
              aria-selected={isSelected}
              onClick={() => onFilterChange({ ...filters, category: cat.name })}
              className={`shrink-0 px-3 py-1.5 text-xs uppercase tracking-wider font-medium rounded-lg transition-all flex items-center gap-1.5 ${
                isSelected
                  ? 'bg-neutral-900 text-white dark:bg-blue-600 dark:text-white shadow-xs font-semibold'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800/60'
              }`}
            >
              <span>{cat.name}</span>
              <span className="text-[10px] font-mono opacity-70 tabular-nums">({cat.count})</span>
            </button>
          );
        })}
      </div>

      {/* Sub-filters & Sort bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs pt-2.5 border-t border-neutral-100 dark:border-neutral-800/70">
        <div className="flex flex-wrap items-center gap-2">
          {/* Auth Filter */}
          <select
            value={filters.authType}
            onChange={(e) => onFilterChange({ ...filters, authType: e.target.value })}
            className="px-2.5 py-1.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 text-neutral-800 dark:text-neutral-200 focus:outline-hidden focus:border-blue-500"
            aria-label="Filter by auth method"
          >
            <option value="all">Auth: All Methods</option>
            <option value="none">No Auth (Public / Open)</option>
            <option value="bearer">Bearer Token</option>
            <option value="header">API Key / Header</option>
            <option value="query">Query Parameter</option>
            <option value="oauth2">OAuth 2.0</option>
            <option value="basic">Basic Auth</option>
          </select>

          {/* Status Filter */}
          <select
            value={filters.status}
            onChange={(e) => onFilterChange({ ...filters, status: e.target.value })}
            className="px-2.5 py-1.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 text-neutral-800 dark:text-neutral-200 focus:outline-hidden focus:border-blue-500"
            aria-label="Filter by status"
          >
            <option value="all">Status: All</option>
            <option value="active">Active</option>
            <option value="testing">Testing</option>
            <option value="deprecated">Deprecated</option>
          </select>

          {/* Favorites Filter */}
          <button
            type="button"
            onClick={() => onFilterChange({ ...filters, onlyFavorites: !filters.onlyFavorites })}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-colors ${
              filters.onlyFavorites
                ? 'border-amber-400 bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 font-semibold'
                : 'border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white'
            }`}
            aria-pressed={filters.onlyFavorites}
          >
            <Star className={`w-3.5 h-3.5 ${filters.onlyFavorites ? 'fill-current text-amber-500' : ''}`} />
            <span>Favorites</span>
          </button>

          {/* HTTPS Only Toggle */}
          <button
            type="button"
            onClick={onToggleHttpsOnly}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-colors ${
              httpsOnly
                ? 'border-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 font-semibold'
                : 'border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white'
            }`}
            aria-pressed={httpsOnly}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>HTTPS Only</span>
          </button>

          {/* CORS Enabled Toggle */}
          <button
            type="button"
            onClick={onToggleCorsOnly}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-colors ${
              corsOnly
                ? 'border-blue-400 bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 font-semibold'
                : 'border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white'
            }`}
            aria-pressed={corsOnly}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>CORS Enabled</span>
          </button>

          {/* Reset button if filter is active */}
          {isAnyFilterActive && (
            <button
              onClick={handleResetFilters}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset Filters</span>
            </button>
          )}
        </div>

        {/* Sort & Count */}
        <div className="flex items-center gap-3">
          <span className="text-neutral-500 dark:text-neutral-400 text-xs">
            Showing <strong className="text-neutral-900 dark:text-white font-mono tabular-nums">{totalFilteredCount}</strong> of <span className="font-mono tabular-nums">{totalAllCount}</span>
          </span>

          <div className="flex items-center gap-1.5">
            <ArrowUpDown className="w-3.5 h-3.5 text-neutral-400" />
            <select
              value={`${filters.sortBy}-${filters.sortOrder}`}
              onChange={(e) => {
                const [field, order] = e.target.value.split('-') as [SortField, SortOrder];
                onFilterChange({ ...filters, sortBy: field, sortOrder: order });
              }}
              className="px-2.5 py-1.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 text-neutral-800 dark:text-neutral-200 focus:outline-hidden focus:border-blue-500"
              aria-label="Sort dataset"
            >
              <option value="name-asc">Name (A-Z)</option>
              <option value="name-desc">Name (Z-A)</option>
              <option value="category-asc">Category (A-Z)</option>
              <option value="authType-asc">Auth Method</option>
              <option value="updatedAt-desc">Recently Updated</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};
