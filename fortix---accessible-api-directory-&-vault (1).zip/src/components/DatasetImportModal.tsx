import React, { useState, useId, useEffect } from 'react';
import { ApiItem } from '../types';
import { parseDatasetInput } from '../utils/datasetParsers';
import { X, Upload, FileText, CheckCircle2, AlertCircle, FileSpreadsheet, Sparkles } from 'lucide-react';

interface DatasetImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (items: ApiItem[], mode: 'replace' | 'append') => void;
}

const SAMPLE_CSV = `Name,URL,API Key,Category,Auth Type,Docs URL,Description
Groq Cloud,https://api.groq.com/openai/v1/chat/completions,gsk_live_90123812903,Artificial Intelligence,bearer,https://console.groq.com/docs,LPU inference engine for open source models
Stripe API,https://api.stripe.com/v1/charges,sk_live_stripe981249812,Payments & Commerce,bearer,https://docs.stripe.com,Online payment processing and subscriptions
WeatherStack,http://api.weatherstack.com/current,ws_key_9182391283912,Weather & Geocoding,query,https://weatherstack.com/documentation,Real-time global weather and historical data
GitHub API,https://api.github.com/user/repos,ghp_token98123981298,Developer Tools,bearer,https://docs.github.com,GitHub repositories and organization automation`;

const SAMPLE_JSON = `[
  {
    "name": "Perplexity AI",
    "url": "https://api.perplexity.ai/chat/completions",
    "apiKey": "pplx-981238912389012389012389012",
    "category": "Artificial Intelligence",
    "authType": "bearer",
    "docsUrl": "https://docs.perplexity.ai",
    "description": "Online conversational LLM with real-time web citations"
  },
  {
    "name": "Coinbase Commerce",
    "url": "https://api.commerce.coinbase.com/charges",
    "apiKey": "cb_live_98120398120398120398",
    "category": "Payments & Commerce",
    "authType": "header",
    "headerKey": "X-CC-Api-Key",
    "docsUrl": "https://docs.cloud.coinbase.com/commerce",
    "description": "Accept cryptocurrency payments directly"
  }
]`;

const SAMPLE_MARKDOWN = `### Animals
API | Description | Auth | HTTPS | CORS 
|:---|:---|:---|:---|:---|
| [AdoptAPet](https://www.adoptapet.com/public/apis/pet_list.html) | Resource to help get pets adopted | \`apiKey\` | Yes | Yes |
| [Cat Facts](https://catfact.ninja/) | Random cat facts | No | Yes | Yes |
| [Dogs](https://dog.ceo/dog-api/) | Based on the Stanford Dogs Dataset | No | Yes | Yes |

### Cryptocurrency
API | Description | Auth | HTTPS | CORS |
|:---|:---|:---|:---|:---|
| [CoinGecko](http://www.coingecko.com/api) | Cryptocurrency Price, Market, and Developer Data | No | Yes | Yes |
| [Binance](https://github.com/binance/binance-spot-api-docs) | Exchange for Trading Cryptocurrencies | \`apiKey\` | Yes | Unknown |

### Weather
API | Description | Auth | HTTPS | CORS |
|:---|:---|:---|:---|:---|
| [Open-Meteo](https://open-meteo.com/) | Global weather forecast API for non-commercial use | No | Yes | Yes |
| [OpenWeatherMap](https://openweathermap.org/api) | Current weather, 5-day forecast | \`apiKey\` | Yes | Unknown |`;

export const DatasetImportModal: React.FC<DatasetImportModalProps> = ({
  isOpen,
  onClose,
  onImport,
}) => {
  const [inputText, setInputText] = useState('');
  const [importMode, setImportMode] = useState<'replace' | 'append'>('replace');
  const [previewItems, setPreviewItems] = useState<Partial<ApiItem>[]>([]);
  const [detectedFormat, setDetectedFormat] = useState<string>('');
  const [parseError, setParseError] = useState<string>('');
  const textareaId = useId();

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  useEffect(() => {
    if (!inputText.trim()) {
      setPreviewItems([]);
      setDetectedFormat('');
      setParseError('');
      return;
    }

    try {
      const { items, detectedFormat: format } = parseDatasetInput(inputText);
      setPreviewItems(items);
      setDetectedFormat(format);
      if (items.length === 0) {
        setParseError('No valid rows or records could be detected in the provided text.');
      } else {
        setParseError('');
      }
    } catch (err: unknown) {
      setParseError(err instanceof Error ? err.message : 'Failed to parse dataset.');
    }
  }, [inputText]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        setInputText(content);
      }
    };
    reader.readAsText(file);
  };

  const handleConfirmImport = () => {
    if (previewItems.length === 0) return;

    const completeItems: ApiItem[] = previewItems.map((item, idx) => ({
      id: item.id || `api-${Date.now()}-${idx}`,
      name: item.name || `API Item ${idx + 1}`,
      category: item.category || 'General',
      url: item.url || 'https://',
      apiKey: item.apiKey || '',
      authType: item.authType || (item.apiKey ? 'bearer' : 'none'),
      headerKey: item.headerKey,
      queryParamKey: item.queryParamKey,
      docsUrl: item.docsUrl,
      description: item.description || `Endpoint for ${item.name}`,
      tags: item.tags || [item.category?.toLowerCase() || 'general'],
      status: item.status || 'active',
      rateLimit: item.rateLimit,
      notes: item.notes,
      isFavorite: false,
      createdAt: item.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }));

    onImport(completeItems, importMode);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-900/60 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-import-title"
    >
      <div className="relative w-full max-w-3xl max-h-[90vh] flex flex-col bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 dark:border-neutral-800">
          <div>
            <h2 id="modal-import-title" className="text-lg font-semibold text-neutral-900 dark:text-neutral-100">
              Import API Dataset
            </h2>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
              Paste or upload CSV, TSV, JSON, or table data containing URLs, API keys, names, and categories.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded-lg transition-colors"
            aria-label="Close import dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
          {/* Quick template loader & file input */}
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-neutral-500 dark:text-neutral-400 font-medium">Load example:</span>
              <button
                type="button"
                onClick={() => setInputText(SAMPLE_CSV)}
                className="px-2.5 py-1 text-xs border border-neutral-200 dark:border-neutral-700 rounded-md hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
              >
                Sample CSV
              </button>
              <button
                type="button"
                onClick={() => setInputText(SAMPLE_JSON)}
                className="px-2.5 py-1 text-xs border border-neutral-200 dark:border-neutral-700 rounded-md hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
              >
                Sample JSON
              </button>
              <button
                type="button"
                onClick={() => setInputText(SAMPLE_MARKDOWN)}
                className="px-2.5 py-1 text-xs border border-neutral-200 dark:border-neutral-700 rounded-md hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors font-medium text-neutral-900 dark:text-neutral-100"
              >
                Public APIs Table
              </button>
            </div>

            <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-neutral-300 dark:border-neutral-700 rounded-md hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors">
              <Upload className="w-3.5 h-3.5 text-neutral-600 dark:text-neutral-300" />
              <span>Upload .csv / .json file</span>
              <input
                type="file"
                accept=".csv,.json,.tsv,.txt"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
          </div>

          {/* Text Area */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label htmlFor={textareaId} className="text-xs font-medium text-neutral-700 dark:text-neutral-300">
                Paste your dataset content
              </label>
              {detectedFormat && (
                <span className="text-xs text-neutral-500 dark:text-neutral-400">
                  Format: <span className="font-medium text-neutral-800 dark:text-neutral-200">{detectedFormat}</span> · {previewItems.length} records parsed
                </span>
              )}
            </div>
            <textarea
              id={textareaId}
              rows={7}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`Paste your dataset here...\n\nExample CSV:\nName,URL,API Key,Category\nOpenAI,https://api.openai.com/v1,sk-live-12345,Artificial Intelligence\nStripe,https://api.stripe.com/v1,sk_live_98765,Payments\n\nOr paste JSON array of objects, or copy directly from Google Sheets.`}
              className="w-full font-mono text-xs p-3 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 focus:outline-hidden focus:ring-2 focus:ring-neutral-900 dark:focus:ring-neutral-100 resize-y"
            />
          </div>

          {/* Parse error if any */}
          {parseError && (
            <div className="flex items-center gap-2 p-3 text-xs text-rose-700 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-lg">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{parseError}</span>
            </div>
          )}

          {/* Live Preview Table */}
          {previewItems.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">
                  Preview of Parsed Data ({previewItems.length} entries ready)
                </span>
                <span className="text-[11px] text-neutral-500 dark:text-neutral-400">
                  Showing first {Math.min(previewItems.length, 4)} records
                </span>
              </div>
              <div className="border border-neutral-200 dark:border-neutral-800 rounded-lg overflow-hidden overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-neutral-100 dark:bg-neutral-800/60 text-neutral-600 dark:text-neutral-400 font-medium border-b border-neutral-200 dark:border-neutral-800">
                    <tr>
                      <th className="py-2 px-3">Name</th>
                      <th className="py-2 px-3">Category</th>
                      <th className="py-2 px-3">URL</th>
                      <th className="py-2 px-3">API Key</th>
                      <th className="py-2 px-3">Auth</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-200 dark:divide-neutral-800">
                    {previewItems.slice(0, 4).map((item, idx) => (
                      <tr key={idx} className="hover:bg-neutral-50 dark:hover:bg-neutral-800/30">
                        <td className="py-2 px-3 font-medium text-neutral-900 dark:text-neutral-100 whitespace-nowrap">
                          {item.name || 'Unnamed'}
                        </td>
                        <td className="py-2 px-3 text-neutral-600 dark:text-neutral-400 whitespace-nowrap">
                          {item.category || 'General'}
                        </td>
                        <td className="py-2 px-3 font-mono text-[11px] text-neutral-500 dark:text-neutral-400 max-w-[180px] truncate">
                          {item.url || '—'}
                        </td>
                        <td className="py-2 px-3 font-mono text-[11px] text-neutral-500 dark:text-neutral-400 whitespace-nowrap">
                          {item.apiKey ? `${item.apiKey.slice(0, 5)}••••` : 'None'}
                        </td>
                        <td className="py-2 px-3 text-neutral-600 dark:text-neutral-400 uppercase text-[10px]">
                          {item.authType || 'bearer'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Import Mode Options */}
          <div className="pt-2 border-t border-neutral-200 dark:border-neutral-800">
            <span className="block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-2">
              Import Action:
            </span>
            <div className="flex flex-col sm:flex-row gap-3">
              <label className="flex items-start gap-2.5 p-3 rounded-lg border border-neutral-200 dark:border-neutral-800 cursor-pointer hover:bg-neutral-50 dark:hover:bg-neutral-800/40 flex-1">
                <input
                  type="radio"
                  name="importMode"
                  value="replace"
                  checked={importMode === 'replace'}
                  onChange={() => setImportMode('replace')}
                  className="mt-0.5"
                />
                <div>
                  <span className="text-xs font-semibold block text-neutral-900 dark:text-neutral-100">
                    Replace existing directory
                  </span>
                  <span className="text-[11px] text-neutral-500 dark:text-neutral-400">
                    Wipes the current list and replaces it entirely with your new dataset.
                  </span>
                </div>
              </label>

              <label className="flex items-start gap-2.5 p-3 rounded-lg border border-neutral-200 dark:border-neutral-800 cursor-pointer hover:bg-neutral-50 dark:hover:bg-neutral-800/40 flex-1">
                <input
                  type="radio"
                  name="importMode"
                  value="append"
                  checked={importMode === 'append'}
                  onChange={() => setImportMode('append')}
                  className="mt-0.5"
                />
                <div>
                  <span className="text-xs font-semibold block text-neutral-900 dark:text-neutral-100">
                    Append to existing directory
                  </span>
                  <span className="text-[11px] text-neutral-500 dark:text-neutral-400">
                    Merges your new dataset records into the existing directory.
                  </span>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-neutral-700 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-neutral-100 transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={previewItems.length === 0}
            onClick={handleConfirmImport}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg text-white bg-neutral-900 dark:bg-neutral-100 dark:text-neutral-900 hover:bg-neutral-800 dark:hover:bg-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Import {previewItems.length > 0 ? `${previewItems.length} Records` : 'Dataset'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
