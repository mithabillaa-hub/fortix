import React, { useEffect } from 'react';
import { X, Command } from 'lucide-react';

interface ShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShortcutsModal: React.FC<ShortcutsModalProps> = ({ isOpen, onClose }) => {
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const shortcuts = [
    { key: '/', description: 'Focus search input' },
    { key: 'n', description: 'Create new API entry' },
    { key: 'i', description: 'Open dataset import dialog' },
    { key: 'e', description: 'Open dataset export dialog' },
    { key: 'm', description: 'Toggle mask / reveal all secrets' },
    { key: '1', description: 'Switch to Grid cards layout' },
    { key: '2', description: 'Switch to Table spreadsheet layout' },
    { key: '3', description: 'Switch to Split inspector layout' },
    { key: '?', description: 'View keyboard shortcuts' },
    { key: 'Esc', description: 'Close any active modal or panel' },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-900/60 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-shortcuts-title"
    >
      <div className="relative w-full max-w-md bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <Command className="w-4 h-4 text-neutral-500" />
            <h2 id="modal-shortcuts-title" className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
              Keyboard Shortcuts
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded-lg transition-colors"
            aria-label="Close shortcuts dialog"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 divide-y divide-neutral-100 dark:divide-neutral-800 text-xs">
          {shortcuts.map((s) => (
            <div key={s.key} className="flex items-center justify-between py-2.5 first:pt-0 last:pb-0">
              <span className="text-neutral-600 dark:text-neutral-400">{s.description}</span>
              <kbd className="font-mono text-[11px] px-2 py-0.5 rounded-md bg-neutral-100 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 font-semibold text-neutral-800 dark:text-neutral-200 shadow-2xs">
                {s.key}
              </kbd>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
