import React, { useState } from 'react';
import { ViewMode, ThemePaletteId } from '../types';
import { THEME_PALETTES } from '../utils/palettes';
import {
  Search,
  Plus,
  Upload,
  Download,
  Eye,
  EyeOff,
  LayoutGrid,
  Table,
  SplitSquareVertical,
  HelpCircle,
  Sun,
  Moon,
  ArrowUpRight,
  Layers,
  Palette,
  Boxes,
  Menu,
  X,
  Compass,
} from 'lucide-react';

interface NavbarProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  viewMode: ViewMode;
  onViewModeChange: (m: ViewMode) => void;
  allKeysMasked: boolean;
  onToggleAllKeysMasked: () => void;
  onOpenAddModal: () => void;
  onOpenImportModal: () => void;
  onOpenExportModal: () => void;
  onOpenShortcutsModal: () => void;
  isDark: boolean;
  onToggleTheme: () => void;
  totalApisCount: number;
  activePaletteId?: ThemePaletteId;
  onChangePalette?: (p: ThemePaletteId) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  searchQuery,
  onSearchChange,
  viewMode,
  onViewModeChange,
  allKeysMasked,
  onToggleAllKeysMasked,
  onOpenAddModal,
  onOpenImportModal,
  onOpenExportModal,
  onOpenShortcutsModal,
  isDark,
  onToggleTheme,
  totalApisCount,
  activePaletteId = 'cersanit',
  onChangePalette,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const currentPalette = THEME_PALETTES[activePaletteId] || THEME_PALETTES.cersanit;

  const scrollToDirectory = () => {
    const el = document.getElementById('api-directory-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`sticky top-0 z-40 w-full border-b backdrop-blur-xl transition-colors duration-200 ${
        isDark
          ? 'border-neutral-800 bg-[#0B0F19]/90 text-neutral-100'
          : 'border-neutral-200/90 bg-white/90 text-[#0F172A]'
      }`}
    >
      {/* Top Architectural Notice Bar */}
      <div className="w-full border-b border-neutral-200/60 dark:border-neutral-800/60 bg-neutral-100/50 dark:bg-neutral-950/40 px-4 py-1 text-[11px] font-mono flex items-center justify-between text-neutral-500 dark:text-neutral-400">
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-blue-600 dark:bg-blue-400" />
          <span>API CONTAINER PLATFORM</span>
          <span aria-hidden="true" className="opacity-40">·</span>
          <span>800+ VERIFIED ENDPOINTS</span>
        </div>
        <div className="hidden sm:flex items-center gap-3">
          <span>DIRECT SITE REDIRECTION ACTIVE</span>
          <span aria-hidden="true" className="opacity-40">·</span>
          <button
            type="button"
            onClick={onOpenShortcutsModal}
            className="hover:text-neutral-900 dark:hover:text-white transition-colors"
          >
            KEYBOARD SHORTCUTS (?)
          </button>
        </div>
      </div>

      {/* Main Spacious Nav with CENTERED BRAND LOGO */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
        
        {/* LEFT NAV LINKS (Minimal Uppercase Cersanit Style) */}
        <nav className="hidden lg:flex items-center gap-6 text-xs uppercase tracking-[0.16em] font-medium text-neutral-600 dark:text-neutral-300">
          <button
            type="button"
            onClick={scrollToDirectory}
            className="hover:text-neutral-900 dark:hover:text-white transition-colors"
          >
            Discovery
          </button>
          <button
            type="button"
            onClick={() => {
              onViewModeChange('grid');
              scrollToDirectory();
            }}
            className={`transition-colors ${
              viewMode === 'grid'
                ? 'text-blue-600 dark:text-blue-400 font-semibold'
                : 'hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            Grid
          </button>
          <button
            type="button"
            onClick={() => {
              onViewModeChange('table');
              scrollToDirectory();
            }}
            className={`transition-colors ${
              viewMode === 'table'
                ? 'text-blue-600 dark:text-blue-400 font-semibold'
                : 'hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            Table
          </button>
          <button
            type="button"
            onClick={() => {
              onViewModeChange('split');
              scrollToDirectory();
            }}
            className={`transition-colors ${
              viewMode === 'split'
                ? 'text-blue-600 dark:text-blue-400 font-semibold'
                : 'hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            Split
          </button>
        </nav>

        {/* Mobile menu trigger */}
        <div className="lg:hidden flex items-center">
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* CENTERED BRAND LOGO (Cersanit Signature Composition) */}
        <div className="flex flex-col items-center justify-center text-center cursor-pointer select-none" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <span className="font-display font-extrabold text-2xl sm:text-3xl tracking-[0.24em] text-neutral-900 dark:text-white uppercase leading-none">
            FORTIX
          </span>
          <span className="text-[9px] font-mono tracking-[0.28em] text-neutral-400 dark:text-neutral-400 uppercase mt-1">
            API CONTAINER & ECOSYSTEM
          </span>
        </div>

        {/* RIGHT CONTROLS & UTILITIES */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Search affordance */}
          <div className="relative hidden md:block w-48 lg:w-56">
            <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              id="global-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search APIs... (/)"
              className="w-full text-xs pl-8 pr-8 py-1.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 focus:outline-hidden focus:border-blue-500 transition-colors"
            />
            <kbd className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] font-mono text-neutral-400 px-1 rounded border border-neutral-200 dark:border-neutral-800">
              /
            </kbd>
          </div>

          {/* Mask / Reveal All Keys Toggle */}
          <button
            type="button"
            onClick={onToggleAllKeysMasked}
            className="p-2 rounded-lg border border-neutral-200 dark:border-neutral-800 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-600 dark:text-neutral-300 transition-colors"
            title={allKeysMasked ? 'Reveal All API Keys' : 'Mask All API Keys'}
            aria-label={allKeysMasked ? 'Reveal All API Keys' : 'Mask All API Keys'}
          >
            {allKeysMasked ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4 text-blue-600 dark:text-blue-400" />}
          </button>

          {/* Add API Button */}
          <button
            type="button"
            onClick={onOpenAddModal}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider bg-neutral-900 text-white dark:bg-blue-600 dark:text-white hover:bg-neutral-800 dark:hover:bg-blue-500 shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add API</span>
          </button>

          {/* Day / Night Mode Switch (Tactile & Reliable) */}
          <button
            type="button"
            onClick={onToggleTheme}
            className={`relative flex items-center gap-1.5 p-1 rounded-full border transition-all ${
              isDark
                ? 'bg-neutral-800 border-neutral-700 text-neutral-200'
                : 'bg-neutral-100 border-neutral-300 text-neutral-800'
            }`}
            title={isDark ? 'Switch to Day Mode (Light)' : 'Switch to Night Mode (Dark)'}
            aria-label={isDark ? 'Switch to Day Mode' : 'Switch to Night Mode'}
          >
            <span
              className={`p-1 rounded-full transition-all ${
                !isDark ? 'bg-white shadow-xs text-amber-500' : 'text-neutral-400'
              }`}
            >
              <Sun className="w-3.5 h-3.5" />
            </span>
            <span
              className={`p-1 rounded-full transition-all ${
                isDark ? 'bg-blue-600 text-white shadow-xs' : 'text-neutral-400'
              }`}
            >
              <Moon className="w-3.5 h-3.5" />
            </span>
          </button>

          {/* Import / Export Menu */}
          <div className="hidden sm:flex items-center gap-1">
            <button
              type="button"
              onClick={onOpenImportModal}
              className="p-2 text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-200 transition-colors"
              title="Import JSON/CSV Dataset"
            >
              <Upload className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onOpenExportModal}
              className="p-2 text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-200 transition-colors"
              title="Export Current Catalog"
            >
              <Download className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-950 px-4 py-4 space-y-3">
          <div className="relative w-full">
            <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search APIs..."
              className="w-full text-xs pl-8 pr-3 py-2 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100"
            />
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs font-medium">
            <button
              type="button"
              onClick={() => {
                onViewModeChange('split');
                setMobileMenuOpen(false);
                scrollToDirectory();
              }}
              className="p-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 text-center uppercase tracking-wider"
            >
              Split View
            </button>
            <button
              type="button"
              onClick={() => {
                onViewModeChange('grid');
                setMobileMenuOpen(false);
                scrollToDirectory();
              }}
              className="p-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 text-center uppercase tracking-wider"
            >
              Grid View
            </button>
            <button
              type="button"
              onClick={() => {
                onViewModeChange('table');
                setMobileMenuOpen(false);
                scrollToDirectory();
              }}
              className="p-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 text-center uppercase tracking-wider"
            >
              Table View
            </button>
            <button
              type="button"
              onClick={() => {
                onOpenAddModal();
                setMobileMenuOpen(false);
              }}
              className="p-2.5 rounded-lg bg-blue-600 text-white text-center uppercase tracking-wider font-semibold"
            >
              + Add API
            </button>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-neutral-100 dark:border-neutral-900 text-xs">
            <button
              type="button"
              onClick={() => {
                onOpenImportModal();
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-1.5 text-neutral-600 dark:text-neutral-400"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Import Dataset</span>
            </button>
            <button
              type="button"
              onClick={() => {
                onOpenExportModal();
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-1.5 text-neutral-600 dark:text-neutral-400"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Catalog</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
