export type AuthType = 'bearer' | 'header' | 'query' | 'basic' | 'oauth2' | 'none';

export type ApiStatus = 'active' | 'testing' | 'deprecated' | 'expired';

export interface ApiItem {
  id: string;
  name: string;
  category: string;
  url: string;
  apiKey: string;
  authType: AuthType;
  headerKey?: string;
  queryParamKey?: string;
  docsUrl?: string;
  description: string;
  tags: string[];
  status: ApiStatus;
  rateLimit?: string;
  notes?: string;
  isFavorite?: boolean;
  createdAt: string;
  updatedAt: string;
}

export type ViewMode = 'grid' | 'table' | 'split';

export type SortField = 'name' | 'category' | 'authType' | 'updatedAt' | 'status';
export type SortOrder = 'asc' | 'desc';

export interface FilterState {
  search: string;
  category: string;
  authType: string;
  status: string;
  onlyFavorites: boolean;
  sortBy: SortField;
  sortOrder: SortOrder;
}

export interface ImportPreviewItem {
  name: string;
  url: string;
  apiKey: string;
  category: string;
  authType?: string;
  docsUrl?: string;
  description?: string;
  tags?: string;
  status?: string;
  notes?: string;
}

export interface TestResult {
  status: number | null;
  statusText: string;
  timeMs: number;
  data: unknown;
  headers: Record<string, string>;
  isError: boolean;
  corsBlocked?: boolean;
}

export type ThemePaletteId = 'cersanit' | 'segesta' | 'fortix-gold' | 'cyber-cyan' | 'monochrome';

export interface ThemePalette {
  id: ThemePaletteId;
  name: string;
  description: string;
  colors: string[];
  primaryAccent: string;
  secondaryAccent: string;
  bgDark: string;
  cardDark: string;
  borderDark: string;
  bgLight: string;
  cardLight: string;
  borderLight: string;
}
