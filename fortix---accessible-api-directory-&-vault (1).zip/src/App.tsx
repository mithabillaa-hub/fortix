import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { ApiItem, ViewMode, FilterState, ThemePaletteId } from './types';
import { loadSavedApis, saveApis, loadMaskPreference, saveMaskPreference } from './utils/storage';
import { THEME_PALETTES, getSavedPalette, savePalette } from './utils/palettes';
import { FORTIX_DATASET } from './data/fortixDataset';
import { Navbar } from './components/Navbar';
import { HeroBanner } from './components/HeroBanner';
import { FilterBar } from './components/FilterBar';
import { ApiCardView } from './components/ApiCardView';
import { ApiTableView } from './components/ApiTableView';
import { ApiDetailModal } from './components/ApiDetailModal';
import { ApiFormModal } from './components/ApiFormModal';
import { DatasetImportModal } from './components/DatasetImportModal';
import { ExportModal } from './components/ExportModal';
import { ShortcutsModal } from './components/ShortcutsModal';
import { ToastContainer, ToastMessage } from './components/Toast';
import { ArrowUpRight, Code, Check, Globe } from 'lucide-react';
import { generateCurlSnippet, generateJsSnippet, generatePythonSnippet } from './utils/codeGenerators';

export default function App() {
  const [apis, setApis] = useState<ApiItem[]>(() => loadSavedApis());
  const [allKeysMasked, setAllKeysMasked] = useState<boolean>(() => loadMaskPreference());
  const [viewMode, setViewMode] = useState<ViewMode>('grid');

  // Palette State (Segesta Twilight, Royal Gold, Cyber Cyan, Titanium Monochrome)
  const [activePaletteId, setActivePaletteId] = useState<ThemePaletteId>(() => getSavedPalette());
  const currentPalette = THEME_PALETTES[activePaletteId] || THEME_PALETTES.segesta;

  // Day / Night Theme state with localStorage persistence
  const [isDark, setIsDark] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('fortix_theme');
      if (saved) return saved === 'dark';
      return true; // Default to signature Segesta twilight dark mode
    } catch {
      return true;
    }
  });

  // Filters
  const [filters, setFilters] = useState<FilterState>({
    search: '',
    category: 'all',
    authType: 'all',
    status: 'all',
    onlyFavorites: false,
    sortBy: 'name',
    sortOrder: 'asc',
  });
  const [httpsOnly, setHttpsOnly] = useState<boolean>(false);
  const [corsOnly, setCorsOnly] = useState<boolean>(false);

  // Modals & Active Selections
  const [selectedApi, setSelectedApi] = useState<ApiItem | null>(null);
  const [editingApi, setEditingApi] = useState<ApiItem | null>(null);
  const [isFormOpen, setIsFormOpen] = useState<boolean>(false);
  const [isImportOpen, setIsImportOpen] = useState<boolean>(false);
  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState<boolean>(false);

  // Split-view inspector active tab
  const [splitSnippetLang, setSplitSnippetLang] = useState<'curl' | 'js' | 'python'>('curl');
  const [copiedSplitSnippet, setCopiedSplitSnippet] = useState<boolean>(false);

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = `${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3200);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Sync APIs to localStorage
  useEffect(() => {
    saveApis(apis);
  }, [apis]);

  // Sync mask preference
  const handleToggleMask = () => {
    const next = !allKeysMasked;
    setAllKeysMasked(next);
    saveMaskPreference(next);
    addToast(next ? 'All API secrets masked' : 'All API secrets revealed', 'info');
  };

  // Day and Night theme effect synchronized with active palette
  useEffect(() => {
    try {
      const themeName = isDark ? 'dark' : 'light';
      document.documentElement.classList.toggle('dark', isDark);
      document.documentElement.setAttribute('data-theme', themeName);
      document.body.classList.toggle('dark', isDark);
      document.body.style.backgroundColor = isDark ? currentPalette.bgDark : currentPalette.bgLight;
      document.body.style.color = isDark ? '#F3F4F6' : '#16152F';
      localStorage.setItem('fortix_theme', themeName);
    } catch {
      // ignore
    }
  }, [isDark, currentPalette]);

  const handleToggleTheme = () => {
    setIsDark((prev) => {
      const next = !prev;
      addToast(next ? 'Switched to Night Mode' : 'Switched to Day Mode', 'info');
      return next;
    });
  };

  const handleChangePalette = (paletteId: ThemePaletteId) => {
    setActivePaletteId(paletteId);
    savePalette(paletteId);
    addToast(`Applied Color Scheme: ${THEME_PALETTES[paletteId]?.name || paletteId}`, 'info');
  };

  // Global Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName) || target.isContentEditable) {
        return;
      }

      if (e.key === '/') {
        e.preventDefault();
        const searchInput = document.getElementById('global-search-input');
        searchInput?.focus();
      } else if (e.key === 'n') {
        e.preventDefault();
        setEditingApi(null);
        setIsFormOpen(true);
      } else if (e.key === 'i') {
        e.preventDefault();
        setIsImportOpen(true);
      } else if (e.key === 'e') {
        e.preventDefault();
        setIsExportOpen(true);
      } else if (e.key === 'm') {
        e.preventDefault();
        handleToggleMask();
      } else if (e.key === '1') {
        setViewMode('grid');
      } else if (e.key === '2') {
        setViewMode('table');
      } else if (e.key === '3') {
        setViewMode('split');
      } else if (e.key === '?') {
        e.preventDefault();
        setIsShortcutsOpen(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [allKeysMasked, handleToggleMask]);

  // Derive unique categories with counts
  const categoriesList = useMemo(() => {
    const countMap: Record<string, number> = {};
    apis.forEach((api) => {
      const cat = api.category || 'General';
      countMap[cat] = (countMap[cat] || 0) + 1;
    });

    return Object.entries(countMap)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);
  }, [apis]);

  // Filtered and Sorted APIs
  const filteredApis = useMemo(() => {
    return apis
      .filter((item) => {
        // Search query
        if (filters.search) {
          const q = filters.search.toLowerCase();
          const matchName = item.name.toLowerCase().includes(q);
          const matchCategory = item.category.toLowerCase().includes(q);
          const matchUrl = item.url.toLowerCase().includes(q);
          const matchDesc = item.description?.toLowerCase().includes(q);
          const matchTags = item.tags.some((t) => t.toLowerCase().includes(q));
          const matchAuth = item.authType.toLowerCase().includes(q);
          if (!matchName && !matchCategory && !matchUrl && !matchDesc && !matchTags && !matchAuth) {
            return false;
          }
        }

        // Category filter
        if (filters.category !== 'all' && item.category !== filters.category) {
          return false;
        }

        // Auth type filter
        if (filters.authType !== 'all') {
          if (filters.authType === 'none' && item.authType !== 'none') return false;
          if (filters.authType !== 'none' && item.authType !== filters.authType) return false;
        }

        // Status filter
        if (filters.status !== 'all' && item.status !== filters.status) {
          return false;
        }

        // Favorites filter
        if (filters.onlyFavorites && !item.isFavorite) {
          return false;
        }

        // HTTPS filter
        if (httpsOnly && !item.url.startsWith('https://')) {
          return false;
        }

        // CORS filter
        if (corsOnly) {
          const hasCorsTag = item.tags.includes('cors-enabled') || item.notes?.toLowerCase().includes('cors: yes');
          if (!hasCorsTag) return false;
        }

        return true;
      })
      .sort((a, b) => {
        let comp = 0;
        if (filters.sortBy === 'name') {
          comp = a.name.localeCompare(b.name);
        } else if (filters.sortBy === 'category') {
          comp = a.category.localeCompare(b.category);
        } else if (filters.sortBy === 'authType') {
          comp = a.authType.localeCompare(b.authType);
        } else if (filters.sortBy === 'updatedAt') {
          comp = new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
        }
        return filters.sortOrder === 'asc' ? comp : -comp;
      });
  }, [apis, filters, httpsOnly, corsOnly]);

  // Handlers for APIs
  const handleSaveApi = (saved: ApiItem) => {
    setApis((prev) => {
      const exists = prev.some((item) => item.id === saved.id);
      if (exists) {
        return prev.map((item) => (item.id === saved.id ? saved : item));
      }
      return [saved, ...prev];
    });
    addToast(`Saved "${saved.name}" successfully`);
  };

  const handleDeleteApi = (id: string) => {
    const item = apis.find((a) => a.id === id);
    setApis((prev) => prev.filter((a) => a.id !== id));
    if (selectedApi?.id === id) setSelectedApi(null);
    addToast(`Deleted "${item?.name || 'API'}"`, 'info');
  };

  const handleToggleFavorite = (id: string) => {
    setApis((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const nextFav = !item.isFavorite;
          addToast(nextFav ? `Added "${item.name}" to favorites` : `Removed "${item.name}" from favorites`, 'info');
          return { ...item, isFavorite: nextFav };
        }
        return item;
      })
    );
  };

  const handleImportDataset = (importedItems: ApiItem[], mode: 'replace' | 'append') => {
    if (mode === 'replace') {
      setApis(importedItems);
      addToast(`Replaced directory with ${importedItems.length} new records!`);
    } else {
      setApis((prev) => [...importedItems, ...prev]);
      addToast(`Appended ${importedItems.length} records to directory!`);
    }
  };

  const handleResetToFortix = () => {
    setApis(FORTIX_DATASET);
    addToast(`Reloaded all ${FORTIX_DATASET.length} Fortix Public APIs!`);
  };

  return (
    <div
      style={{
        backgroundColor: isDark ? currentPalette.bgDark : currentPalette.bgLight,
        color: isDark ? '#F3F4F6' : '#16152F',
      }}
      className="min-h-screen flex flex-col transition-colors selection:bg-[#FFA586] selection:text-[#16152F]"
    >
      {/* Toast Manager */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />

      {/* Top Navigation */}
      <Navbar
        searchQuery={filters.search}
        onSearchChange={(q) => setFilters((prev) => ({ ...prev, search: q }))}
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        allKeysMasked={allKeysMasked}
        onToggleAllKeysMasked={handleToggleMask}
        onOpenAddModal={() => {
          setEditingApi(null);
          setIsFormOpen(true);
        }}
        onOpenImportModal={() => setIsImportOpen(true)}
        onOpenExportModal={() => setIsExportOpen(true)}
        onOpenShortcutsModal={() => setIsShortcutsOpen(true)}
        isDark={isDark}
        onToggleTheme={handleToggleTheme}
        totalApisCount={apis.length}
        activePaletteId={activePaletteId}
        onChangePalette={handleChangePalette}
      />

      {/* Hero Banner with 3D Golden Sculpture & Color Schemes */}
      <HeroBanner
        totalApisCount={apis.length}
        totalCategoriesCount={categoriesList.length}
        onOpenImportModal={() => setIsImportOpen(true)}
        onResetFortixApis={handleResetToFortix}
        isDark={isDark}
        activePaletteId={activePaletteId}
        onChangePalette={handleChangePalette}
      />

      {/* Filter and Categorization Bar */}
      <FilterBar
        categories={categoriesList}
        filters={filters}
        onFilterChange={setFilters}
        httpsOnly={httpsOnly}
        onToggleHttpsOnly={() => setHttpsOnly(!httpsOnly)}
        corsOnly={corsOnly}
        onToggleCorsOnly={() => setCorsOnly(!corsOnly)}
        totalFilteredCount={filteredApis.length}
        totalAllCount={apis.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-7xl mx-auto flex flex-col">
        {/* Layout Render */}
        {viewMode === 'grid' && (
          <ApiCardView
            items={filteredApis}
            allKeysMasked={allKeysMasked}
            onEditApi={(api) => {
              setEditingApi(api);
              setIsFormOpen(true);
            }}
            onDeleteApi={handleDeleteApi}
            onToggleFavorite={handleToggleFavorite}
            onNotify={addToast}
          />
        )}

        {viewMode === 'table' && (
          <ApiTableView
            items={filteredApis}
            allKeysMasked={allKeysMasked}
            onEditApi={(api) => {
              setEditingApi(api);
              setIsFormOpen(true);
            }}
            onDeleteApi={handleDeleteApi}
            onToggleFavorite={handleToggleFavorite}
            onNotify={addToast}
          />
        )}

        {viewMode === 'split' && (
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 p-4 sm:px-6 lg:px-8 my-4">
            {/* Left list pane (5 cols) */}
            <div className="lg:col-span-5 flex flex-col space-y-2.5 max-h-[calc(100vh-210px)] overflow-y-auto pr-1">
              {filteredApis.map((api) => {
                const isSelected = selectedApi?.id === api.id;
                return (
                  <div
                    key={api.id}
                    onClick={() => setSelectedApi(api)}
                    className={`p-4 rounded-2xl border text-xs cursor-pointer transition-all ${
                      isSelected
                        ? 'border-[#FFA586] bg-white dark:bg-[#242F49] shadow-md ring-1 ring-[#FFA586]'
                        : 'border-neutral-200 dark:border-[#384358]/80 bg-white dark:bg-[#242F49]/60 hover:border-neutral-400 dark:hover:border-[#FFA586]/60'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-neutral-900 dark:text-neutral-100">{api.name}</span>
                      <span className="text-[10px] text-neutral-500 dark:text-[#FFA586] font-mono uppercase">
                        {api.authType}
                      </span>
                    </div>
                    <div className="text-[11px] text-neutral-500 dark:text-neutral-300 mt-1 truncate">
                      {api.category} · {api.url}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Right details inspector pane (7 cols) with Direct Redirect Button */}
            <div className="lg:col-span-7 bg-white dark:bg-[#242F49]/80 border border-neutral-200 dark:border-[#384358] rounded-2xl p-6 shadow-md max-h-[calc(100vh-210px)] overflow-y-auto backdrop-blur-md">
              {selectedApi ? (
                <div className="space-y-5">
                  <div className="flex items-start justify-between border-b border-neutral-200 dark:border-[#384358]/80 pb-4">
                    <div>
                      <h2 className="text-xl font-bold text-neutral-900 dark:text-neutral-100">
                        {selectedApi.name}
                      </h2>
                      <div className="text-xs text-neutral-500 dark:text-[#FFA586] mt-1 font-medium">
                        <span>{selectedApi.category}</span> · <span className="font-mono uppercase">{selectedApi.authType}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {/* Prominent Direct Redirect Button */}
                      <a
                        href={selectedApi.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-xl bg-neutral-900 text-white dark:bg-[#FFA586] dark:text-[#16152F] hover:bg-neutral-800 dark:hover:bg-[#ffb59c] shadow-sm transition-all"
                      >
                        <span>Visit Site</span>
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </a>
                      <button
                        onClick={() => {
                          setEditingApi(selectedApi);
                          setIsFormOpen(true);
                        }}
                        className="px-3 py-2 text-xs font-medium border border-neutral-300 dark:border-[#384358] rounded-xl hover:bg-neutral-100 dark:hover:bg-[#384358] text-neutral-700 dark:text-neutral-200 transition-colors"
                      >
                        Edit
                      </button>
                    </div>
                  </div>

                  {/* URL with quick copy */}
                  <div className="space-y-1.5">
                    <span className="text-xs font-semibold text-neutral-700 dark:text-neutral-300">
                      Endpoint URL
                    </span>
                    <div className="p-3 font-mono text-xs bg-neutral-50 dark:bg-[#16152F] border border-neutral-200 dark:border-[#384358] rounded-xl break-all flex items-center justify-between">
                      <a
                        href={selectedApi.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:underline text-neutral-800 dark:text-neutral-200 hover:text-[#B51A2B] dark:hover:text-[#FFA586]"
                      >
                        {selectedApi.url}
                      </a>
                    </div>
                  </div>

                  {selectedApi.apiKey && (
                    <div className="space-y-1.5">
                      <span className="text-xs font-semibold text-neutral-700 dark:text-neutral-300">
                        API Key / Secret
                      </span>
                      <div className="p-3 font-mono text-xs bg-neutral-50 dark:bg-[#16152F] border border-neutral-200 dark:border-[#384358] rounded-xl break-all text-neutral-800 dark:text-neutral-200">
                        {allKeysMasked ? `${selectedApi.apiKey.slice(0, 4)}••••••••` : selectedApi.apiKey}
                      </div>
                    </div>
                  )}

                  {/* Description & Notes */}
                  <div className="space-y-1.5">
                    <span className="text-xs font-semibold text-neutral-700 dark:text-neutral-300">
                      Overview
                    </span>
                    <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
                      {selectedApi.description}
                    </p>
                    {selectedApi.notes && (
                      <div className="mt-2 text-xs p-3 rounded-xl bg-neutral-50 dark:bg-[#16152F] border border-neutral-200 dark:border-[#384358] text-neutral-600 dark:text-neutral-300">
                        {selectedApi.notes}
                      </div>
                    )}
                  </div>

                  {/* Code snippet quick preview */}
                  <div className="space-y-2 pt-2 border-t border-neutral-200 dark:border-[#384358]/80">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1 text-xs">
                        {(['curl', 'js', 'python'] as const).map((lang) => (
                          <button
                            key={lang}
                            onClick={() => setSplitSnippetLang(lang)}
                            className={`px-3 py-1 uppercase rounded-lg text-[11px] font-medium transition-colors ${
                              splitSnippetLang === lang
                                ? 'bg-neutral-900 text-white dark:bg-[#FFA586] dark:text-[#16152F]'
                                : 'text-neutral-500 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100'
                            }`}
                          >
                            {lang === 'js' ? 'JavaScript' : lang}
                          </button>
                        ))}
                      </div>

                      <button
                        onClick={() => {
                          const snip =
                            splitSnippetLang === 'curl'
                              ? generateCurlSnippet(selectedApi)
                              : splitSnippetLang === 'js'
                              ? generateJsSnippet(selectedApi)
                              : generatePythonSnippet(selectedApi);
                          navigator.clipboard.writeText(snip);
                          setCopiedSplitSnippet(true);
                          addToast(`Copied ${splitSnippetLang.toUpperCase()} snippet`);
                          setTimeout(() => setCopiedSplitSnippet(false), 2000);
                        }}
                        className="inline-flex items-center gap-1 text-xs text-neutral-600 dark:text-[#FFA586] hover:underline"
                      >
                        {copiedSplitSnippet ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Code className="w-3.5 h-3.5" />}
                        <span>{copiedSplitSnippet ? 'Copied' : 'Copy Snippet'}</span>
                      </button>
                    </div>

                    <pre className="font-mono text-xs p-3.5 rounded-xl bg-neutral-950 text-neutral-100 border border-neutral-800 overflow-x-auto max-h-48">
                      {splitSnippetLang === 'curl'
                        ? generateCurlSnippet(selectedApi)
                        : splitSnippetLang === 'js'
                        ? generateJsSnippet(selectedApi)
                        : generatePythonSnippet(selectedApi)}
                    </pre>
                  </div>
                </div>
              ) : (
                <div className="text-center py-24 text-xs text-neutral-400">
                  Select an API from the list to view details and snippets.
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Cersanit-Inspired Architectural Footer */}
      <footer className="w-full border-t border-neutral-200/90 dark:border-neutral-800/90 bg-white/60 dark:bg-neutral-950/60 mt-16 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex flex-col items-center md:items-start text-center md:text-left">
            <span className="font-display font-extrabold text-xl tracking-[0.24em] text-neutral-900 dark:text-white uppercase">
              FORTIX
            </span>
            <p className="text-[11px] font-mono tracking-wider text-neutral-400 dark:text-neutral-500 uppercase mt-0.5">
              API CONTAINER & GATEWAY ECOSYSTEM
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 text-xs uppercase tracking-wider text-neutral-500 dark:text-neutral-400 font-medium">
            <button
              type="button"
              onClick={() => {
                const el = document.getElementById('api-directory-section');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="hover:text-neutral-900 dark:hover:text-white transition-colors"
            >
              Directory
            </button>
            <button
              type="button"
              onClick={() => {
                setViewMode('grid');
                const el = document.getElementById('api-directory-section');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="hover:text-neutral-900 dark:hover:text-white transition-colors"
            >
              Grid
            </button>
            <button
              type="button"
              onClick={() => {
                setViewMode('table');
                const el = document.getElementById('api-directory-section');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="hover:text-neutral-900 dark:hover:text-white transition-colors"
            >
              Table
            </button>
            <button
              type="button"
              onClick={() => setIsImportOpen(true)}
              className="hover:text-neutral-900 dark:hover:text-white transition-colors"
            >
              Import Data
            </button>
            <button
              type="button"
              onClick={() => setIsExportOpen(true)}
              className="hover:text-neutral-900 dark:hover:text-white transition-colors"
            >
              Export
            </button>
            <button
              type="button"
              onClick={() => setIsShortcutsOpen(true)}
              className="hover:text-neutral-900 dark:hover:text-white transition-colors"
            >
              Shortcuts
            </button>
          </div>

          <div className="text-center md:text-right text-[11px] font-mono text-neutral-400 dark:text-neutral-500">
            <span>Client-Side Key Encryption</span>
            <span aria-hidden="true" className="mx-2">·</span>
            <span>Direct Site Redirection</span>
          </div>
        </div>
      </footer>
      <ApiFormModal
        isOpen={isFormOpen}
        onClose={() => {
          setIsFormOpen(false);
          setEditingApi(null);
        }}
        onSave={handleSaveApi}
        editingItem={editingApi}
        existingCategories={categoriesList.map((c) => c.name)}
      />

      {/* Dataset Import Modal */}
      <DatasetImportModal
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        onImport={handleImportDataset}
      />

      {/* Export Modal */}
      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        items={filteredApis}
        onNotify={addToast}
      />

      {/* Shortcuts Modal */}
      <ShortcutsModal
        isOpen={isShortcutsOpen}
        onClose={() => setIsShortcutsOpen(false)}
      />

      {/* API Detail Inspector Modal */}
      {viewMode !== 'split' && (
        <ApiDetailModal
          api={selectedApi}
          isOpen={Boolean(selectedApi)}
          onClose={() => setSelectedApi(null)}
          onEdit={(api) => {
            setSelectedApi(null);
            setEditingApi(api);
            setIsFormOpen(true);
          }}
          onNotify={addToast}
        />
      )}
    </div>
  );
}
